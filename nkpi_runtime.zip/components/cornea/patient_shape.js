/* Patient-linked corneal shape. Image estimates and measured exports are kept
 * distinct. No generic cone, fitted progression model, remote reader or PHI log. */
(function(root){'use strict';
const node=typeof module!=='undefined'&&module.exports;
const I=node?require('../image_regions.js'):root.NKPIImageRegions;
const C=node?require('./surface_schema.js'):root.CornealData;
const S=node?require('./shape_inspection.js'):root.NKPIShapeInspection;
const finite=Number.isFinite,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function solve(a,b){a=a.map((r,i)=>[...r,b[i]]);for(let i=0;i<b.length;i++){let k=i;for(let j=i+1;j<b.length;j++)if(Math.abs(a[j][i])>Math.abs(a[k][i]))k=j;[a[i],a[k]]=[a[k],a[i]];if(Math.abs(a[i][i])<1e-10)return null;const v=a[i][i];a[i]=a[i].map(x=>x/v);for(let j=0;j<b.length;j++)if(j!==i){const f=a[j][i];a[j]=a[j].map((x,q)=>x-f*a[i][q]);}}return a.map(r=>r[b.length]);}
function smooth(grid,i,j,step){
 // Local weighted plane, including nearest-support and coverage requirements.
 // Works at the same physical resolution for central41 and full printed61 grids.
 const size=grid.length,center=(size-1)/2,radius=.6,n=Math.ceil(radius/step),points=[];let possible=0,near=Infinity;
 for(let y=Math.max(0,j-n);y<=Math.min(size-1,j+n);y++)for(let x=Math.max(0,i-n);x<=Math.min(size-1,i+n);x++){
  const dx=(x-i)*step,dy=(y-j)*step,d=Math.hypot(dx,dy);if(d>radius||Math.hypot(x-center,y-center)>center)continue;possible++;const q=grid[y][x];if(q){points.push({dx,dy,v:q.value,w:Math.exp(-d*d/.08)});near=Math.min(near,d);}
 }
 if(points.length<6||points.length<possible*.5||near>Math.max(step*2.01,.25))return null;
 const a=Array.from({length:3},()=>[0,0,0]),b=[0,0,0];for(const p of points){const v=[1,p.dx,p.dy];for(let k=0;k<3;k++){b[k]+=p.w*v[k]*p.v;for(let l=0;l<3;l++)a[k][l]+=p.w*v[k]*v[l];}}
 const fit=solve(a,b);return fit?{value:fit[0],dx:fit[1],dy:fit[2],interpolated:!grid[j][i]}:null;
}
function imageGrid(map,key,full=true){
 const selected=full&&map.full_display?map.full_display:map,grid=selected[key],size=grid.length,center=(size-1)/2,radius=map.diameter_mm*(selected===map?map.extent:1)/2;
 return {grid,size,center,radius,step:radius/center,full:selected!==map};
}
function smoothPhysical(g,x,y){
 const u=x/g.step+g.center,v=y/g.step+g.center;
 if(u<0||v<0||u>g.size-1||v>g.size-1||Math.hypot(x,y)>g.radius+1e-8)return null;
 return smooth(g.grid,Math.round(u),Math.round(v),g.step);
}
function sampleImageElevation(map,x,y){
 const g=imageGrid(map,'elevation_um'),u=x/g.step+g.center,v=-y/g.step+g.center;
 if(u<0||v<0||u>g.size-1||v>g.size-1||Math.hypot(x,y)>g.radius+1e-8)return null;
 const i=Math.min(g.size-2,Math.floor(u)),j=Math.min(g.size-2,Math.floor(v)),fx=u-i,fy=v-j;
 const cells=[[i,j,(1-fx)*(1-fy)],[i+1,j,fx*(1-fy)],[i,j+1,(1-fx)*fy],[i+1,j+1,fx*fy]].filter(q=>q[2]>1e-8);
 return cells.every(([a,b])=>finite(g.grid[b][a]?.value))?cells.reduce((s,[a,b,w])=>s+g.grid[b][a].value*w,0):null;
}
function imageModel(shape,thickness=null){
 I.validateShape(shape);if(thickness)I.validateMap(thickness);
 if(thickness&&(thickness.id!=='thickness'||Math.abs(shape.diameter_mm-thickness.diameter_mm)>.001))throw Error('Elevation and thickness need the same printed plot diameter.');
 // Full display fields are independently sampled from the original plot. They
 // never enlarge or rescale the existing central grid used for regional work.
 function build(full){
  const grid=imageGrid(shape,'elevation_um',full),{radius,step,size:nx,center}=grid,R=shape.bfs_radius_mm,vertices=[];
  const tg=thickness?imageGrid(thickness,'grid',full):null;let possible=0,interpolated=0;
  for(let j=0;j<nx;j++)for(let i=0;i<nx;i++){
   const x=(i-center)*step,y=(j-center)*step;if(Math.hypot(x,y)>radius+1e-8){vertices.push(null);continue;}possible++;
   const e=smooth(grid.grid,i,j,step),t=tg?smoothPhysical(tg,x,y):null;
   if(!e||R*R<=x*x+y*y){vertices.push(null);continue;}
   const tv=t&&t.value>=100&&t.value<=1200?t.value:null;
   const sag=Math.sqrt(R*R-x*x-y*y),z=sag-R+e.value/1000,dx=-x/sag+e.dx/1000,dy=y/sag-e.dy/1000,den=Math.hypot(dx,dy,1),normal=[-dx/den,-dy/den,1/den];
   const front=[x,-y,z],back=finite(tv)?front.map((v,k)=>v-normal[k]*tv/1000):null;
   if(!front.every(finite)||(back&&!back.every(finite))){vertices.push(null);continue;}
   const local=e.interpolated||Boolean(finite(tv)&&t.interpolated);if(local)interpolated++;
   vertices.push({front,back,thickness:tv,interpolated:local,elevation:e.value,posterior_elevation:shape.posterior_elevation?sampleImageElevation(shape.posterior_elevation,front[0],front[1]):null});
  }
  const valid=vertices.filter(Boolean);if(valid.length/possible<.5)throw Error('Too little elevation coverage for a 3D estimate.');
  return finish({vertices,nx,ny:nx,axisX:Array.from({length:nx},(_,i)=>(i-center)*step),axisY:Array.from({length:nx},(_,j)=>(center-j)*step),kind:'estimated',mapSource:'image',mapDefinitions:shape.posterior_elevation?{posterior_elevation:{type:'best_fit_sphere',reference:'independent_posterior_float_bfs',fit_diameter_mm:shape.posterior_elevation.fit_diameter_mm}}:{},posteriorBfs:shape.posterior_elevation?.bfs_radius_mm??null,fullDisplayUsed:grid.full,radius,coverage:valid.length/possible,interpolated,possible,bfs:R,fit_diameter:shape.fit_diameter_mm,legend_step:shape.legend_step_um});
 }
 if(shape.full_display){try{return build(true);}catch(e){const m=build(false);m.fullDisplayIssue=e.message;return m;}}
 return build(false);
}
function nativeModel(raw,eye,visit){
 const s=C.validate(raw);if(s.kind!=='measured'||s.eye!==eye||s.visit!==visit||!s.anterior?.z_mm)throw Error('A matching measured anterior height grid is needed.');
 const cs=s.coordinate_system,mx=(cs.x_positive==='temporal'?1:-1)*(eye==='OD'?-1:1),my=cs.y_positive==='superior'?1:-1,mz=cs.z_positive==='anterior'?1:-1;
 const radius=Math.min(6,Math.max(...s.x_mm.map(Math.abs)),Math.max(...s.y_mm.map(Math.abs)));
 const vertices=[];let possible=0;for(let j=0;j<s.y_mm.length;j++)for(let i=0;i<s.x_mm.length;i++){
  const x=s.x_mm[i]*mx,y=s.y_mm[j]*my;if(Math.hypot(x,y)>radius){vertices.push(null);continue;}possible++;
  const z=s.anterior.z_mm[j][i],b=s.posterior?.z_mm?.[j]?.[i],t=s.thickness_um?.[j]?.[i];
  if(!finite(z)||(finite(b)&&mz*z<=mz*b))vertices.push(null);else vertices.push({front:[x,y,mz*z],back:finite(b)?[x,y,mz*b]:null,thickness:finite(t)?t:null,interpolated:false,elevation:s.anterior.elevation_um?.[j]?.[i]??null,posterior_elevation:s.posterior?.elevation_um?.[j]?.[i]??null,anterior:s.anterior.curvature_D?.[j]?.[i]??null,posterior:s.posterior?.curvature_D?.[j]?.[i]??null});
 }
 if(!vertices.some(Boolean))throw Error('No usable height samples in the source field.');
 return finish({vertices,nx:s.x_mm.length,ny:s.y_mm.length,axisX:s.x_mm.map(x=>x*mx),axisY:s.y_mm.map(y=>y*my),kind:'native',mapSource:'native',mapDefinitions:numericMapDefinitions(s),radius,coverage:vertices.filter(Boolean).length/possible,possible,interpolated:0});
}
function numericMapDefinitions(s){
 const definitions={},definition_id=s.comparison?.map_definition_id||null;
 for(const side of ['anterior','posterior']){
  if(s[side]?.curvature_D)definitions[side]={type:s[side].curvature_type,definition_id};
  if(s[side]?.elevation_um)definitions[side==='anterior'?'elevation':'posterior_elevation']={...s[side].elevation_reference,definition_id};
 }
 if(s.thickness_um)definitions.thickness={type:s.thickness_definition,definition_id};
 return definitions;
}
// Numerical maps retain their native axes even when no anterior height grid
// is available. Their reference sphere is illustrative and never an elevation
// reconstruction; native map locations are not registered to report pixels.
function nativeReferenceModel(raw,eye,visit){
 const s=C.validate(raw);if(s.kind!=='measured'||s.eye!==eye||s.visit!==visit)throw Error('Matching measured numerical maps are needed.');
 const cs=s.coordinate_system,mx=(cs.x_positive==='temporal'?1:-1)*(eye==='OD'?-1:1),my=cs.y_positive==='superior'?1:-1;
 const radius=Math.min(6,Math.max(...s.x_mm.map(Math.abs)),Math.max(...s.y_mm.map(Math.abs))),R=7.8,vertices=[];let possible=0;
 for(let j=0;j<s.y_mm.length;j++)for(let i=0;i<s.x_mm.length;i++){
  const x=s.x_mm[i]*mx,y=s.y_mm[j]*my,r=Math.hypot(x,y);if(r>radius+1e-8){vertices.push(null);continue;}possible++;
  const z=Math.sqrt(R*R-r*r)-R,front=[x,y,z],normal=[x/R,y/R,(z+R)/R],t=s.thickness_um?.[j]?.[i];
  const thickness=finite(t)?t:null,back=finite(thickness)?front.map((v,k)=>v-normal[k]*thickness/1000):null;
  vertices.push({front,back,thickness,interpolated:false,elevation:s.anterior?.elevation_um?.[j]?.[i]??null,posterior_elevation:s.posterior?.elevation_um?.[j]?.[i]??null,anterior:s.anterior?.curvature_D?.[j]?.[i]??null,posterior:s.posterior?.curvature_D?.[j]?.[i]??null});
 }
 const m=finish({vertices,nx:s.x_mm.length,ny:s.y_mm.length,axisX:s.x_mm.map(x=>x*mx),axisY:s.y_mm.map(y=>y*my),kind:'reference',mapSource:'native',mapDefinitions:numericMapDefinitions(s),radius,coverage:1,possible,interpolated:0,bfs:R});
 m.referenceReason='Anterior height coordinates are unavailable. Supplied numerical maps are located on an illustrative reference cornea; map values do not determine its shape.';
 return m;
}
function finish(m){
 const triangles=[];for(let j=0;j<m.ny-1;j++)for(let i=0;i<m.nx-1;i++){const a=j*m.nx+i,b=a+1,c=a+m.nx,d=c+1;for(const ids of [[a,b,c],[b,d,c]])if(ids.every(k=>m.vertices[k]))triangles.push(ids);}
 if(!triangles.length)throw Error('No complete surface cells.');m.triangles=triangles;
 const ts=m.vertices.flatMap(v=>v&&finite(v.thickness)?[v.thickness]:[]);m.thicknessRange=ts.length?[Math.min(...ts),Math.max(...ts)]:null;
 m.centerZ=m.vertices.filter(Boolean).reduce((s,v)=>s+v.front[2],0)/m.vertices.filter(Boolean).length;
 return prepare(m);
}
function referenceModel(maps=[]){
 for(const map of maps)I.validateMap(map);
 const full=maps.some(m=>m.full_display),radius=Math.max(3,...maps.map(m=>imageGrid(m,'grid').radius)),R=Math.max(7.8,radius+.4),vertices=[],ts=maps.filter(m=>m.id==='thickness'),size=full?61:41,center=(size-1)/2,step=radius/center;
 const thickness=ts.length===1?imageGrid(ts[0],'grid'):null;
 for(let j=0;j<size;j++)for(let i=0;i<size;i++){
  const x=(i-center)*step,y=(j-center)*step,r=Math.hypot(x,y);if(r>radius+1e-8){vertices.push(null);continue;}
  const z=Math.sqrt(R*R-r*r)-R,front=[x,-y,z],n=unit([x/R,-y/R,(z+R)/R]);
  let t=thickness?smoothPhysical(thickness,x,y)?.value??null:null;
  if(finite(t)&&(t<100||t>1200))t=null;vertices.push({front,back:finite(t)?front.map((v,k)=>v-n[k]*t/1000):null,thickness:t,elevation:null,interpolated:false});
 }
 return addImageOverlays(finish({vertices,nx:size,ny:size,axisX:Array.from({length:size},(_,i)=>(i-center)*step),axisY:Array.from({length:size},(_,j)=>(center-j)*step),kind:'reference',mapSource:'image',fullDisplayUsed:full,radius,coverage:1,possible:vertices.filter(Boolean).length,interpolated:0,bfs:R}),maps);
}
function fromReport(s){
 if(!s)throw Error('No report is linked to this visit.');
 if(s.surface?.kind==='measured')return s.surface.anterior?.z_mm?nativeModel(s.surface,s.eye,s.visit):nativeReferenceModel(s.surface,s.eye,s.visit);
 const maps=s.image_maps||[],ts=maps.filter(v=>v.id==='thickness');
 if(s.shape_estimate&&ts.length<=1){try{return addImageOverlays(imageModel(s.shape_estimate,ts[0]||null),maps);}catch(e){const m=referenceModel(maps);m.referenceReason=e.message;return m;}}
 const m=referenceModel(maps);m.referenceReason=s.shape_issue||'Usable anterior elevation is unavailable or the source maps are ambiguous.';return m;
}

// Curvature is a color overlay, never a substitute for surface height. Sample
// in the report's physical frame; missing values remain missing on the mesh.
function addImageOverlays(m,maps){
 m.mapDefinitions=m.mapDefinitions||{};
 for(const id of ['anterior','posterior']){
  const candidates=maps.filter(v=>v.id===id);if(candidates.length!==1)continue;
  const map=I.validateMap(candidates[0]),g=imageGrid(map,'grid');
  m.mapDefinitions[id]={type:map.map_type,definition_id:null};
  for(const v of m.vertices){if(!v)continue;const u=v.front[0]/g.step+g.center,w=-v.front[1]/g.step+g.center;
   if(u<0||w<0||u>g.size-1||w>g.size-1||Math.hypot(v.front[0],v.front[1])>g.radius+1e-8)continue;
   const i=Math.min(g.size-2,Math.floor(u)),j=Math.min(g.size-2,Math.floor(w)),fx=u-i,fy=w-j;
   const points=[[i,j,(1-fx)*(1-fy)],[i+1,j,fx*(1-fy)],[i,j+1,(1-fx)*fy],[i+1,j+1,fx*fy]].filter(p=>p[2]>1e-8);
   const vals=points.map(([x,y,weight])=>({value:I.canonicalValue(g.grid[y][x],id,map.unit)?.value,weight}));
   v[id]=vals.every(p=>finite(p.value))?vals.reduce((s,p)=>s+p.value*p.weight,0):null;
  }
 }
 return prepare(m);
}
const sub=(a,b)=>a.map((v,i)=>v-b[i]);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const unit=a=>{const d=Math.hypot(...a)||1;return a.map(v=>v/d);};
function prepare(m){
 reliefCache.delete(m);
 delete m.mapDisplay;delete m.displayMesh;delete m.referenceEye;delete m.gapFaces;delete m.anatomyMesh;delete m.anatomyCoarse;delete m.renderFaces;
 for(const v of m.vertices)if(v){v.frontNormal=[0,0,0];v.backNormal=[0,0,0];}
 for(const ids of m.triangles)for(const side of ['front','back']){
  const vs=ids.map(i=>m.vertices[i]);if(vs.some(v=>!v[side]))continue;
  let n=cross(sub(vs[1][side],vs[0][side]),sub(vs[2][side],vs[0][side]));
  if((side==='front'?1:-1)*n[2]<0)n=n.map(v=>-v);
  for(const v of vs)for(let i=0;i<3;i++)v[side+'Normal'][i]+=n[i];
 }
 for(const v of m.vertices)if(v)for(const side of ['front','back'])v[side+'Normal']=unit(v[side+'Normal']);
 m.overlays=[{id:'form',label:'Surface shape',unit:''},{id:'shape',label:'Natural eye',unit:''}];
 for(const [id,label,u]of [['thickness','Thickness','µm'],['anterior','Anterior curvature','D'],['posterior','Posterior curvature |D|','D'],['elevation','Anterior elevation','µm'],['posterior_elevation','Posterior elevation','µm']]){
  const values=m.vertices.flatMap(v=>v&&finite(v[id])?[id==='posterior'?Math.abs(v[id]):v[id]]:[]);
  if(values.length){
   const definition=m.mapDefinitions?.[id]||null,curvature=id==='anterior'||id==='posterior',type=curvature&&definition?.type;
   const dataMin=Math.min(...values),dataMax=Math.max(...values);
   m.overlays.push({id,label:type?label+' ('+type.replace(/_/g,' ')+')':label,unit:u,min:dataMin,max:dataMax,dataMin,dataMax,definition,mapSource:m.mapSource||'unknown',coverage:values.length/m.vertices.filter(Boolean).length});
  }
 }
 if(m.overlays.some(l=>l.id==='anterior')&&m.overlays.some(l=>l.id==='thickness'))m.overlays.unshift({id:'combined',label:'Curvature + thickness',unit:''});
 return m;
}
function rotate(v,yaw,pitch,roll=0){const rx=v[0]*Math.cos(roll)-v[1]*Math.sin(roll),ry=v[0]*Math.sin(roll)+v[1]*Math.cos(roll),x=rx*Math.cos(yaw)+v[2]*Math.sin(yaw),z=-rx*Math.sin(yaw)+v[2]*Math.cos(yaw);return [x,ry*Math.cos(pitch)-z*Math.sin(pitch),ry*Math.sin(pitch)+z*Math.cos(pitch)];}
function project(m,v,state,width=1000,height=680){const center=state.eyeContext?(m.globeCenter??referenceEye(m).apex-9.5):(m.focusZ??m.centerZ),p=rotate([v[0],v[1],v[2]-center],state.yaw,state.pitch,state.roll||0),scale=Math.min(width*.41,height*.36)/(state.eyeContext?12:m.radius)*(state.zoom||1);return [width*.5+p[0]*scale,height*.48-p[1]*scale,p[2],scale];}
function paletteColor(m,id,value){
 if(id==='form')return [151,202,216];
 if(id==='shape')return [116,186,207];
 if(!finite(value))return [70,80,95];
 const layer=m.overlays.find(v=>v.id===id),number=id==='posterior'?Math.abs(value):value,f=clamp((number-layer.min)/Math.max(1e-8,layer.max-layer.min),0,1);
 const stops=id==='thickness'?[[139,105,208],[133,182,217],[188,228,222]]:[[73,132,197],[80,181,188],[221,211,123],[213,126,100]];
 const x=f*(stops.length-1),i=Math.min(stops.length-2,Math.floor(x)),t=x-i;return stops[i].map((v,k)=>v*(1-t)+stops[i+1][k]*t);
}
function meshFaces(m,cut,hideGapWalls=false){
 const faces=[],edges=new Map();
 for(const ids of m.triangles){if(cut&&ids.some(i=>m.vertices[i].front[0]>1e-8))continue;
  for(const side of ['back','front'])if(ids.every(i=>m.vertices[i][side]))faces.push({ids,side});
  for(const [a,b]of [[ids[0],ids[1]],[ids[1],ids[2]],[ids[2],ids[0]]]){const key=[a,b].sort((a,b)=>a-b).join(':');if(edges.has(key))edges.delete(key);else edges.set(key,[a,b]);}
 }
 for(const [a,b]of edges.values()){const v=m.vertices[a],w=m.vertices[b],rim=m.displayRadius||m.radius,onRim=[v,w].every(q=>Math.abs(Math.hypot(q.front[0],q.front[1])-rim)<.035),onCut=cut&&[v,w].every(q=>Math.abs(q.front[0])<1e-6);if(hideGapWalls&&!onRim&&!onCut)continue;if(v.back&&w.back){const n=unit(cross(sub(w.front,v.front),sub(v.back,v.front)));faces.push({ids:[a,b,b],side:'wall',positions:[v.front,w.front,w.back],normal:n});faces.push({ids:[a,b,a],side:'wall',positions:[v.front,w.back,v.back],normal:n});}}
 return faces;
}
// Clip only the outer display rim slightly inside the sampled aperture. This
// removes staircase edges without extending geometry into unmeasured tissue.
// All new vertices are linear interpolation within an existing valid triangle.
function displayMesh(m){
 if(m.displayMesh)return m.displayMesh;
 const steps=m.vertices.filter(Boolean).map(v=>v.front[0]).sort((a,b)=>a-b),gaps=steps.slice(1).map((v,i)=>v-steps[i]).filter(v=>v>1e-6),step=gaps.length?Math.min(...gaps):m.radius/20;
 const radius=m.radius-Math.min(step*1.2,m.radius*.08),vertices=[],triangles=[];
 const point=(v,id)=>({...v,sourceId:id});
 function blend(a,b,t){const out={};for(const k of ['front','back','frontNormal','backNormal'])out[k]=a[k]&&b[k]?a[k].map((v,i)=>v*(1-t)+b[k][i]*t):null;
 for(const k of ['thickness','elevation','posterior_elevation','anterior','posterior'])out[k]=finite(a[k])&&finite(b[k])?a[k]*(1-t)+b[k]*t:null;
 out.sourceId=t<.5?a.sourceId:b.sourceId;return out;}
 const planes=Array.from({length:96},(_,i)=>[Math.cos(i*2*Math.PI/96),Math.sin(i*2*Math.PI/96)]);
 for(const ids of m.triangles){let poly=ids.map(i=>point(m.vertices[i],i));
  if(poly.some(v=>Math.hypot(v.front[0],v.front[1])>radius))for(const [nx,ny]of planes){
   const out=[];for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],da=a.front[0]*nx+a.front[1]*ny-radius,db=b.front[0]*nx+b.front[1]*ny-radius;
    if(da<=0)out.push(a);if((da<0&&db>0)||(da>0&&db<0))out.push(blend(a,b,da/(da-db)));
   }poly=out;if(!poly.length)break;
  }
  const offset=vertices.length;vertices.push(...poly);for(let i=1;i<poly.length-1;i++)triangles.push([offset,offset+i,offset+i+1]);
 }
 // Shared coordinate keys preserve only actual boundary walls after clipping.
 const lookup=new Map(),unique=[],index=vertices.map(v=>{const key=v.front.map(x=>x.toFixed(8)).join(':');if(!lookup.has(key)){lookup.set(key,unique.length);unique.push(v);}return lookup.get(key);});
 m.displayMesh={...m,vertices:unique,triangles:triangles.map(ids=>ids.map(i=>index[i])),displayRadius:radius};return m.displayMesh;
}

// Only small image-label gaps receive a bounded display interpolation. Native
// numerical maps and every original sample/null remain untouched. The rendered
// estimate is never used for point readouts, contour values, or calculations.
function boundedMapDisplay(source){
 if(source.mapDisplay)return source.mapDisplay;
 const nx=source.nx,ny=source.ny,xs=source.axisX,ys=source.axisY,fields={},filled={};
 const dxs=xs.slice(1).map((x,i)=>Math.abs(x-xs[i])).filter(x=>x>1e-8),dys=ys.slice(1).map((y,i)=>Math.abs(y-ys[i])).filter(y=>y>1e-8),step=Math.min(...dxs,...dys),radius=.6;
 for(const id of ['thickness','anterior','posterior','elevation','posterior_elevation']){
  const values=source.vertices.map(v=>v&&finite(v[id])?v[id]:null),mask=values.map(()=>false),out=values.slice();
  if(!values.some(finite))continue;
  if(source.mapSource==='image')for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){
   const k=j*nx+i;if(finite(values[k])||Math.hypot(xs[i],ys[j])>source.radius+1e-8)continue;
   const points=[],quadrants=new Set();let possible=0,near=Infinity;
   for(let y=0;y<ny;y++){
    const dy=ys[y]-ys[j];if(Math.abs(dy)>radius)continue;
    for(let x=0;x<nx;x++){
     const dx=xs[x]-xs[i],distance=Math.hypot(dx,dy);if(distance>radius||Math.hypot(xs[x],ys[y])>source.radius+1e-8)continue;possible++;
     const value=values[y*nx+x];if(!finite(value))continue;
     points.push({dx,dy,value,w:Math.exp(-distance*distance/.08)});near=Math.min(near,distance);
     if(Math.abs(dx)>1e-8&&Math.abs(dy)>1e-8)quadrants.add((dx>0?1:0)+(dy>0?2:0));
    }
   }
   if(points.length<6||points.length<possible*.5||near>Math.max(step*2.01,.25)||quadrants.size<3)continue;
   const a=Array.from({length:3},()=>[0,0,0]),b=[0,0,0];for(const p of points){const v=[1,p.dx,p.dy];for(let q=0;q<3;q++){b[q]+=p.w*v[q]*p.value;for(let z=0;z<3;z++)a[q][z]+=p.w*v[q]*v[z];}}
   const fit=solve(a,b);if(!fit)continue;
   out[k]=clamp(fit[0],Math.min(...points.map(p=>p.value)),Math.max(...points.map(p=>p.value)));mask[k]=true;
  }
  fields[id]=out;filled[id]=mask;
 }
 return source.mapDisplay={fields,filled};
}

// A separate presentation surface. Observed source samples remain immutable.
// Harmonic continuation fills holes in height residuals, not clinical maps.
// The peripheral Hermite transition is reference anatomy, never patient data.
function anatomicalMesh(source){
 if(source.anatomyMesh)return source.anatomyMesh;
 const nx=source.nx,ny=source.ny,xs=source.axisX,ys=source.axisY;
 const inAxisBounds=(x,y)=>x>=Math.min(xs[0],xs[nx-1])-1e-9&&x<=Math.max(xs[0],xs[nx-1])+1e-9&&y>=Math.min(ys[0],ys[ny-1])-1e-9&&y<=Math.max(ys[0],ys[ny-1])+1e-9;
 const limbus=Math.max(5.7,source.radius+.35),R=Math.max(limbus+.4,source.bfs||7.8);
 const sag=(x,y)=>Math.sqrt(Math.max(.01,R*R-x*x-y*y))-R;
 const known=source.vertices.filter(Boolean),offsets=known.map(v=>v.front[2]-sag(v.front[0],v.front[1])).sort((a,b)=>a-b),offset=offsets[Math.floor(offsets.length/2)];
 const residual=source.vertices.map((v,k)=>v?v.front[2]-sag(xs[k%nx],ys[Math.floor(k/nx)])-offset:null);
 function fill(values,fallback){
  const observed=values.filter(finite);if(!observed.length)return values.map(()=>fallback);
  const mean=observed.reduce((a,b)=>a+b,0)/observed.length,a=values.map(v=>finite(v)?v:mean),unknown=values.map((v,k)=>finite(v)?-1:k).filter(k=>k>=0);
  // Unequal grid spacing is respected. Fixed source nodes are never relaxed.
  for(let it=0;it<500;it++){let change=0;for(const k of unknown){const i=k%nx,j=Math.floor(k/nx);let total=0,weight=0;
   for(const [di,dj]of [[-1,0],[1,0],[0,-1],[0,1]]){const u=i+di,v=j+dj;if(u<0||v<0||u>=nx||v>=ny)continue;const d=di?Math.abs(xs[u]-xs[i]):Math.abs(ys[v]-ys[j]),w=1/Math.max(1e-8,d*d);total+=a[v*nx+u]*w;weight+=w;}
   const value=total/weight;change=Math.max(change,Math.abs(value-a[k]));a[k]=value;
  }if(change<1e-7)break;}return a;
 }
 const filledZ=fill(residual,0),filledT=fill(source.vertices.map(v=>v&&finite(v.thickness)?v.thickness:null),550);
 const display=boundedMapDisplay(source),displayFields=display.fields;
 const backs=[0,1,2].map(axis=>fill(source.vertices.map(v=>v?.back?v.back[axis]-v.front[axis]:null),axis===2?-.55:0));
 const anyBack=known.some(v=>v.back),anyThickness=known.some(v=>finite(v.thickness));
 function bracket(axis,value){const asc=axis[axis.length-1]>axis[0];let lo=0,hi=axis.length-1;while(hi-lo>1){const mid=(lo+hi)>>1;if((value>=axis[mid])===asc)lo=mid;else hi=mid;}return [lo,clamp((value-axis[lo])/(axis[lo+1]-axis[lo]),0,1)];}
 function weights(x,y){const [i,u]=bracket(xs,x),[j,v]=bracket(ys,y);return [[j*nx+i,(1-u)*(1-v)],[j*nx+i+1,u*(1-v)],[(j+1)*nx+i,(1-u)*v],[(j+1)*nx+i+1,u*v]].filter(q=>q[1]>1e-9);}
 const interp=(field,w)=>w.reduce((a,[k,t])=>a+field[k]*t,0);
 function rawAt(x,y){return interp(filledZ,weights(x,y));}
 function height(x,y){const r=Math.hypot(x,y);if(r<=source.radius)return offset+sag(x,y)+rawAt(x,y);
  const a=x/r,b=y/r,r0=source.radius,dr=Math.min(.3,r0/4),d0=rawAt(a*r0,b*r0),d1=clamp((d0-rawAt(a*(r0-dr),b*(r0-dr)))/dr,-.3,.3),span=limbus-r0,t=clamp((r-r0)/span,0,1);
  return offset+sag(x,y)+(2*t*t*t-3*t*t+1)*d0+(t*t*t-2*t*t+t)*span*d1;
 }
 const startZ=height(0,0),limbusZ=offset+sag(limbus,0),globeCenter=limbusZ-Math.sqrt(12*12-limbus*limbus);
 function point(x,y){const r=Math.hypot(x,y),inside=r<=source.radius+1e-8&&inAxisBounds(x,y),w=weights(x,y),supported=inside&&w.every(([k])=>source.vertices[k]),nearest=supported?w.reduce((a,b)=>a[1]>b[1]?a:b)[0]:-1;
  const z=height(x,y),eps=.015,dx=(height(x+eps,y)-height(x-eps,y))/(2*eps),dy=(height(x,y+eps)-height(x,y-eps))/(2*eps),normal=unit([-dx,-dy,1]);
  const front=[x,y,z],edgeW=weights(r?x*Math.min(r,source.radius)/r:0,r?y*Math.min(r,source.radius)/r:0),blend=inside?0:clamp((r-source.radius)/(limbus-source.radius),0,1),fade=blend*blend*(3-2*blend);
  let t=interp(filledT,edgeW)/1000;t=t*(1-fade)+.65*fade;
  let delta=anyBack?backs.map(f=>interp(f,edgeW)):normal.map(v=>-v*t);
  if(!inside)delta=delta.map((v,k)=>v*(1-fade)-normal[k]*.65*fade);
  // Missing posterior coordinates with supplied pachymetry use the local normal.
  if(inside&&(!anyBack||!supported||w.some(([k])=>!source.vertices[k]?.back)))delta=normal.map(v=>-v*t);
  const back=front.map((v,k)=>v+delta[k]);
  const v={front,back,sourceId:nearest,provenance:!inside||source.kind==='reference'?'reference':supported?'source':'filled',displayThickness:t*1000,interpolated:!supported};
  // Exact original overlays only; gap-filled geometry has no invented readout.
  v.displayValues={};v.displayInterpolated={};for(const id of ['thickness','anterior','posterior','elevation','posterior_elevation']){v[id]=supported&&w.every(([k])=>finite(source.vertices[k][id]))?w.reduce((s,[k,f])=>s+source.vertices[k][id]*f,0):null;v.displayValues[id]=inside&&displayFields[id]&&w.every(([k])=>finite(displayFields[id][k]))?interp(displayFields[id],w):null;v.displayInterpolated[id]=finite(v.displayValues[id])&&w.some(([k])=>display.filled[id]?.[k]);}
  // Reference shape may still carry real source maps. An ID is permitted only
  // where original finite overlay values support that local readout. Clamped
  // sampling outside native axes is reference completion, never patient data.
  v.mapSupported=supported&&['thickness','anterior','posterior','elevation','posterior_elevation'].some(id=>finite(v[id]));
  if(source.kind==='reference'&&!v.mapSupported)v.sourceId=-1;
  return v;
 }
 const vertices=[point(0,0)],triangles=[],segments=128,rings=76;
 for(let j=1;j<=rings;j++){const r=limbus*j/rings;for(let i=0;i<segments;i++){const a=i*2*Math.PI/segments;vertices.push(point(r*Math.cos(a),r*Math.sin(a)));}}
 for(let i=0;i<segments;i++)triangles.push([0,1+i,1+(i+1)%segments]);
 for(let j=1;j<rings;j++)for(let i=0;i<segments;i++){const a=1+(j-1)*segments+i,b=1+(j-1)*segments+(i+1)%segments,c=1+j*segments+i,d=1+j*segments+(i+1)%segments;triangles.push([a,b,c],[b,d,c]);}
 const m={...source,vertices,triangles,radius:limbus,displayRadius:limbus,dataRadius:source.radius,focusZ:source.centerZ,centerZ:startZ-1.1,apex:startZ,limbusZ,globeCenter,isAnatomy:true,referenceInner:!anyBack&&!anyThickness,sample:point};
 delete m.anatomyMesh;prepare(m);m.overlays=source.overlays;m.fillStats={source:vertices.filter(v=>v.provenance==='source').length,filled:vertices.filter(v=>v.provenance==='filled').length,reference:vertices.filter(v=>v.provenance==='reference').length};
 source.anatomyMesh=m;return m;
}

function interactiveMesh(source){
 if(source.anatomyCoarse)return source.anatomyCoarse;
 const full=anatomicalMesh(source),vertices=[{...full.vertices[0]}],triangles=[],N=64,J=38;
 for(let j=1;j<=J;j++)for(let i=0;i<N;i++)vertices.push({...full.vertices[1+(2*j-1)*128+2*i]});
 for(let i=0;i<N;i++)triangles.push([0,1+i,1+(i+1)%N]);
 for(let j=1;j<J;j++)for(let i=0;i<N;i++){const a=1+(j-1)*N+i,b=1+(j-1)*N+(i+1)%N,c=1+j*N+i,d=1+j*N+(i+1)%N;triangles.push([a,b,c],[b,d,c]);}
 const m={...full,vertices,triangles};prepare(m);m.overlays=full.overlays;source.anatomyCoarse=m;return m;
}

function referenceEye(m){
 if(m.referenceEye)return m.referenceEye;
 if(m.isAnatomy){
  const faces=[],R=12,N=128,limbus=m.radius,cz=m.globeCenter;
  function rings(rows,color,kind){for(let j=1;j<rows.length;j++)for(let i=0;i<N;i++){const a=rows[j-1][i],b=rows[j-1][(i+1)%N],c=rows[j][i],d=rows[j][(i+1)%N];for(const p of [[a,b,c],[b,d,c]])faces.push({reference:true,kind,positions:p.map(v=>v.p),normals:p.map(v=>v.n),colors:p.map(v=>typeof color==='function'?color(v):color)});}}
  rings(Array.from({length:55},(_,j)=>Array.from({length:N},(_,i)=>{const t=Math.asin(limbus/R)+(Math.PI-Math.asin(limbus/R))*j/54,a=i*2*Math.PI/N,n=[Math.sin(t)*Math.cos(a),Math.sin(t)*Math.sin(a),Math.cos(t)];return {p:[R*n[0],R*n[1],cz+R*n[2]],n};})),[224,227,229],'sclera');
  const z=m.limbusZ-.55;
  rings(Array.from({length:35},(_,j)=>Array.from({length:N},(_,i)=>{const r=(limbus-.08)*j/34,a=i*2*Math.PI/N;return {p:[r*Math.cos(a),r*Math.sin(a),z],n:[0,0,1],r,a};})),v=>{if(v.r<1.85)return [5,12,17];const f=Math.sin(v.a*67+v.r*1.1)+.4*Math.sin(v.a*91-v.r*.8),inner=Math.exp(-Math.pow((v.r-2.2)/.7,2)),rim=clamp((v.r-(limbus-.6))/.5,0,1);return [51+13*f+inner*34,85+15*f+inner*2,86+12*f-inner*22].map(q=>q*(1-rim*.6));},'iris');
  return m.referenceEye={faces,apex:m.apex};
 }
 const center=m.vertices.filter(Boolean).sort((a,b)=>Math.hypot(...a.front.slice(0,2))-Math.hypot(...b.front.slice(0,2)))[0],apex=center?.front[2]||0;
 const faces=[],R=12,limbus=5.7,cz=apex-Math.sqrt(R*R-limbus*limbus)-2.48,N=80;
 function ringMesh(rings,color,kind){for(let j=1;j<rings.length;j++)for(let i=0;i<N;i++){const a=rings[j-1][i],b=rings[j-1][(i+1)%N],c=rings[j][i],d=rings[j][(i+1)%N];for(const pts of [[a,b,c],[b,d,c]])faces.push({reference:true,kind,positions:pts.map(p=>p.p),normals:pts.map(p=>p.n),colors:pts.map(p=>typeof color==='function'?color(p):color)});}}
 const sclera=Array.from({length:39},(_,j)=>{const t=Math.asin(limbus/R)+(Math.PI-Math.asin(limbus/R)-.001)*j/38;return Array.from({length:N},(_,i)=>{const a=i*2*Math.PI/N,n=[Math.sin(t)*Math.cos(a),Math.sin(t)*Math.sin(a),Math.cos(t)];return {p:[R*n[0],R*n[1],cz+R*n[2]],n};});});
 ringMesh(sclera,[213,222,226],'sclera');
 const iris=Array.from({length:13},(_,j)=>Array.from({length:N},(_,i)=>{const r=5.65*j/12,a=i*2*Math.PI/N;return {p:[r*Math.cos(a),r*Math.sin(a),apex-3.25],n:[0,0,1],r,a};}));
 ringMesh(iris,p=>p.r<1.85?[8,16,23]:p.r>5.25?[27,45,49]:[55+12*Math.sin(p.a*29),93+15*Math.sin(p.a*29),94+12*Math.sin(p.a*29)],'iris');
 // Reference peripheral cornea, beyond the data patch. Its shape and placement
 // are schematic. It is NEVER joined into the patient's numerical mesh.
 const inner=Math.min(5.5,m.displayRadius||m.radius),cornea=Array.from({length:16},(_,j)=>Array.from({length:N},(_,i)=>{const r=inner+(5.7-inner)*j/15,a=i*2*Math.PI/N,z=Math.sqrt(7.8**2-r*r)-7.8;return {p:[r*Math.cos(a),r*Math.sin(a),apex+z],n:[r*Math.cos(a)/7.8,r*Math.sin(a)/7.8,(z+7.8)/7.8]};}));
 ringMesh(cornea,[98,174,193],'reference_cornea');
 return m.referenceEye={faces,apex};
}

// Neutral reference patches occupy only unsupported display triangles. They
// carry no measurements or picking IDs; original nulls and all analyses remain.
function gapReference(m,displayRadius){
 if(m.gapFaces)return m.gapFaces;
 if(!m.axisX||!m.axisY)return [];
 const R=m.bfs||7.8,sag=(x,y)=>Math.sqrt(Math.max(.001,R*R-x*x-y*y))-R;
 const offset=m.vertices.filter(Boolean).reduce((n,v)=>n+v.front[2]-sag(v.front[0],v.front[1]),0)/m.vertices.filter(Boolean).length;
 const faces=[],planes=Array.from({length:64},(_,i)=>[Math.cos(i*Math.PI/32),Math.sin(i*Math.PI/32)]);
 for(let j=0;j<m.ny-1;j++)for(let i=0;i<m.nx-1;i++)for(const ids of [[j*m.nx+i,j*m.nx+i+1,(j+1)*m.nx+i],[j*m.nx+i+1,(j+1)*m.nx+i+1,(j+1)*m.nx+i]]){
  if(ids.every(k=>m.vertices[k]||Math.hypot(m.axisX[k%m.nx],m.axisY[Math.floor(k/m.nx)])>m.radius+1e-8))continue;
  let poly=ids.map(k=>{const x=m.axisX[k%m.nx],y=m.axisY[Math.floor(k/m.nx)];return m.vertices[k]?.front||[x,y,offset+sag(x,y)];});
  if(poly.every(p=>Math.hypot(p[0],p[1])>displayRadius+.3))continue;
  if(poly.some(p=>Math.hypot(p[0],p[1])>displayRadius))for(const [nx,ny]of planes){const out=[];for(let k=0;k<poly.length;k++){const a=poly[k],b=poly[(k+1)%poly.length],da=a[0]*nx+a[1]*ny-displayRadius,db=b[0]*nx+b[1]*ny-displayRadius;if(da<=0)out.push(a);if(da*db<0){const t=da/(da-db);out.push(a.map((v,k)=>v*(1-t)+b[k]*t));}}poly=out;if(!poly.length)break;}
  for(let k=1;k<poly.length-1;k++){const positions=[poly[0],poly[k],poly[k+1]],n=unit(cross(sub(positions[1],positions[0]),sub(positions[2],positions[0])));faces.push({reference:true,kind:'missing_data',positions,normals:positions.map(()=>n),colors:positions.map(()=>[155,163,176])});}
 }
 return m.gapFaces=faces;
}
// Visual exaggeration changes only an ephemeral drawing mesh, never the source
// coordinates, normal thickness, contour values, readouts or score.
const reliefCache=new WeakMap();
function emphasizeElevation(m,factor=1){
 factor=finite(factor)?clamp(factor,1,6):1;
 if(factor===1||m.kind!=='estimated')return m;
 let variants=reliefCache.get(m);if(!variants){variants=new Map();reliefCache.set(m,variants);}if(variants.has(factor))return variants.get(factor);
 const vertices=m.vertices.map(v=>{if(!v)return null;const dz=finite(v.elevation)?(factor-1)*v.elevation/1000:0;return {...v,front:[v.front[0],v.front[1],v.front[2]+dz],back:v.back?[v.back[0],v.back[1],v.back[2]+dz]:null};});
 const out={...m,vertices};prepare(out);out.overlays=m.overlays;variants.set(factor,out);return out;
}
function thicknessContours(m){
 const l=m.overlays.find(l=>l.id==='thickness');if(!l||l.max-l.min<2)return [];
 const step=Math.max(10,Math.ceil((l.max-l.min)/5/10)*10),levels=[];
 for(let v=Math.ceil(l.min/step)*step;v<l.max;v+=step)if(v>l.min)levels.push(v);
 const out=[];
 for(const level of levels)for(const ids of m.triangles){const vs=ids.map(i=>m.vertices[i]);if(vs.some(v=>!finite(v.thickness)))continue;const points=[];for(const [a,b]of [[vs[0],vs[1]],[vs[1],vs[2]],[vs[2],vs[0]]]){if((a.thickness<=level&&b.thickness>level)||(b.thickness<=level&&a.thickness>level)){const f=(level-a.thickness)/(b.thickness-a.thickness);points.push(a.front.map((v,k)=>v*(1-f)+b.front[k]*f));}}if(points.length===2)out.push({level,points});}
 return out;
}
// Dependency-free, depth-buffered software rendering. Smooth normals affect
// lighting only; the mesh's coordinates and missing-region mask are unchanged.
function render(canvas,m,options={}){
 const original=m;const state={yaw:-.82,pitch:-.10,roll:0,zoom:1,eyeContext:false,cut:false,color:'form',coverage:false,emphasis:1,profile:false,eye:'OS',visit:'latest',...options};state.emphasis=m.kind==='estimated'&&finite(state.emphasis)?clamp(state.emphasis,1,6):1;
 const displaySource=emphasizeElevation(original,state.emphasis);m=state.interactive?interactiveMesh(displaySource):anatomicalMesh(displaySource);const base=anatomicalMesh(original),w=canvas.width,h=canvas.height,compact=w<650,ctx=canvas.getContext('2d'),bg=ctx.createLinearGradient(0,0,w,h);
 bg.addColorStop(0,'#111c2e');bg.addColorStop(1,'#060c16');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);
 const glow=ctx.createRadialGradient(w*.43,h*.4,10,w*.43,h*.4,w*.43);glow.addColorStop(0,'rgba(47,74,103,.35)');glow.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=glow;ctx.fillRect(0,0,w,h);
 const img=ctx.getImageData(0,0,w,h),pixels=img.data,zbuf=new Float32Array(w*h).fill(-Infinity),pick=new Int32Array(w*h).fill(-1),key=unit([-.7,.8,1.3]),fill=unit([.7,-.1,.6]),half=unit([key[0],key[1],key[2]+1]);
 const cache=m.vertices.map(v=>v?Object.fromEntries(['front','back'].filter(side=>v[side]).map(side=>[side,{p:project(m,v[side],state,w,h),n:rotate(v[side+'Normal'],state.yaw,state.pitch,state.roll)}])):null);
 const reference=referenceEye(m).faces,missing=[],colorID=state.color==='combined'?'anterior':state.color;
 const requestedMap=!['shape','form'].includes(state.color),mapMode=!state.coverage&&requestedMap&&m.overlays.some(l=>l.id===state.color)&&m.overlays.some(l=>l.id===colorID);
 const faceKey=state.cut?'cut':'whole';m.renderFaces=m.renderFaces||{};const shell=m.renderFaces[faceKey]||(m.renderFaces[faceKey]=meshFaces(m,state.cut,true).sort((a,b)=>({back:0,front:1,wall:2}[a.side]-{back:0,front:1,wall:2}[b.side])));
 for(const face of [...reference,...shell]){
  const ref=face.reference,vs=ref?[]:face.ids.map(i=>m.vertices[i]),wall=face.side==='wall';
  const ps=ref||wall?face.positions.map(v=>project(m,v,state,w,h)):face.ids.map(i=>cache[i][face.side].p);
  const ns=ref?face.normals.map(n=>rotate(n,state.yaw,state.pitch,state.roll)):wall?ps.map(()=>rotate(face.normal,state.yaw,state.pitch,state.roll)):face.ids.map(i=>cache[i][face.side].n);
  const mapValue=v=>m.mapSource==='image'?v.displayValues?.[colorID]:v[colorID];
  const quantitative=mapMode&&!ref&&!wall&&face.side==='front'&&vs.every(v=>finite(mapValue(v)));
  const unsupported=!state.coverage&&requestedMap&&!ref&&!wall&&face.side==='front'&&!quantitative&&vs.every(v=>Math.hypot(v.front[0],v.front[1])<=original.radius+1e-8);
  const colors=ref?face.colors:vs.map(v=>{if(wall)return [213,180,108];if(unsupported)return [64,75,90];if(state.coverage){if(requestedMap)return m.overlays.some(l=>l.id===state.color)&&finite(v[colorID])?[82,184,174]:m.overlays.some(l=>l.id===state.color)&&v.displayInterpolated?.[colorID]?[197,153,90]:[128,141,160];return v.provenance==='source'?[82,184,174]:v.provenance==='filled'?[197,153,90]:[128,141,160];}if(quantitative)return paletteColor(m,colorID,mapValue(v));if(face.side==='back')return [91,146,166];if(state.color==='shape'||state.color==='form')return paletteColor(m,state.color,0);return [133,148,166];});
  const [a,b,c]=ps,den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);if(Math.abs(den)<1e-8)continue;
  const x0=Math.max(0,Math.floor(Math.min(...ps.map(p=>p[0])))),x1=Math.min(w-1,Math.ceil(Math.max(...ps.map(p=>p[0])))),y0=Math.max(0,Math.floor(Math.min(...ps.map(p=>p[1])))),y1=Math.min(h-1,Math.ceil(Math.max(...ps.map(p=>p[1]))));
  const noOverlay=requestedMap&&!ref&&!wall&&!quantitative&&!unsupported;
  // Smooth per-vertex lighting avoids expensive per-pixel normal/specular work.
  const shaded=ns.map((normal,i)=>{if(quantitative||unsupported)return [...colors[i],1];let [nx,ny,nz]=unit(normal);if(nz<0){nx=-nx;ny=-ny;nz=-nz;}
   const diffuse=Math.max(0,nx*key[0]+ny*key[1]+nz*key[2]),secondary=Math.max(0,nx*fill[0]+ny*fill[1]+nz*fill[2]),spec=Math.pow(Math.max(0,nx*half[0]+ny*half[1]+nz*half[2]),32),rim=Math.pow(1-nz,3),light=ref&&face.kind==='sclera'?.55+.30*diffuse+.15*secondary:.27+.58*diffuse+.14*secondary;
   const materialLight=state.color==='form'&&!ref&&!wall?.16+.70*diffuse+.14*secondary:light;
   const rgb=colors[i].map(base=>{const value=clamp(base*(state.color==='combined'&&!ref&&!wall?.55+.35*diffuse+.1*secondary:materialLight)+(wall?18:state.color==='combined'?45:state.color==='form'?90:160)*spec+rim*38,0,255);return ref&&face.kind==='sclera'?Math.sqrt(value/255)*255:value;});
   return [...rgb,!ref&&(state.color==='shape'||noOverlay)&&!wall&&!state.coverage?(face.side==='back'?.035+.08*rim:.065+.52*rim+.4*spec):1];
  });
  for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
   const u=((b[1]-c[1])*(x+.5-c[0])+(c[0]-b[0])*(y+.5-c[1]))/den,v=((c[1]-a[1])*(x+.5-c[0])+(a[0]-c[0])*(y+.5-c[1]))/den,t=1-u-v;
   if(u<-.001||v<-.001||t<-.001)continue;const depth=u*a[2]+v*b[2]+t*c[2],idx=y*w+x;if(depth<=zbuf[idx])continue;
   zbuf[idx]=depth;pick[idx]=ref||wall||vs.some(q=>q.sourceId<0)||(requestedMap&&vs.some(q=>!finite(q[colorID])))?-1:m.vertices[face.ids[u>v&&u>t?0:v>t?1:2]].sourceId;
   if(quantitative){
    // Interpolate the source scalar before applying its palette. Quantitative
    // colors stay opaque and unlit, matching the legend through camera moves.
    const value=u*mapValue(vs[0])+v*mapValue(vs[1])+t*mapValue(vs[2]),rgb=paletteColor(m,colorID,value);
    for(let k=0;k<3;k++)pixels[idx*4+k]=rgb[k];
    continue;
   }
   const alpha=shaded[0][3]*u+shaded[1][3]*v+shaded[2][3]*t;
   for(let k=0;k<3;k++)pixels[idx*4+k]=alpha*(shaded[0][k]*u+shaded[1][k]*v+shaded[2][k]*t)+(1-alpha)*pixels[idx*4+k];
  }
 }
 ctx.putImageData(img,0,0);
 // Readable annotation bands remain outside the anatomy's quantitative layers.
 const topShade=ctx.createLinearGradient(0,0,0,100);topShade.addColorStop(0,'rgba(7,16,28,.96)');topShade.addColorStop(1,'rgba(7,16,28,0)');ctx.fillStyle=topShade;ctx.fillRect(0,0,w,100);
 const bottomShade=ctx.createLinearGradient(0,h-110,0,h);bottomShade.addColorStop(0,'rgba(7,16,28,0)');bottomShade.addColorStop(1,'rgba(7,16,28,.98)');ctx.fillStyle=bottomShade;ctx.fillRect(0,h-110,w,110);
 if(state.color==='combined'&&mapMode&&!state.coverage){
  if(!state.interactive)drawThicknessContours();if(!compact){const l=m.overlays.find(l=>l.id==='anterior'),x=w*.74,y=42,bw=w*.21,g=ctx.createLinearGradient(x,0,x+bw,0);
  for(const t of [0,.33,.67,1])g.addColorStop(t,'rgb('+paletteColor(m,'anterior',l.min+(l.max-l.min)*t).map(Math.round).join(',')+')');
  ctx.fillStyle=g;ctx.fillRect(x,y,bw,7);ctx.font=Math.round(w*.012)+'px system-ui';ctx.fillStyle='#cad7e7';ctx.textAlign='left';ctx.fillText(l.sharedScale?'Curvature · shared scale':'Curvature · this scan',x,y-10);ctx.fillText(l.min.toFixed(1)+' D',x,y+25);ctx.textAlign='right';ctx.fillText(l.max.toFixed(1)+' D',x+bw,y+25);
 }}
 const font=Math.max(13,w*.014);ctx.font=font+'px system-ui';ctx.textAlign='center';ctx.fillStyle='#b9cadc';
 const r=(state.eyeContext?6.7:original.radius*1.13);if(!state.profile)for(const [label,v]of [['Superior',[0,r,0]],['Inferior',[0,-r,0]],[state.eye==='OD'?'Temporal':'Nasal',[-r,0,0]],[state.eye==='OD'?'Nasal':'Temporal',[r,0,0]]]){if(v[0]&&Math.abs(Math.cos(state.yaw))<.3)continue;const p=project(m,v,state,w,h),x=clamp(p[0],50,w-50),y=clamp(p[1],105,h-120),tw=ctx.measureText(label).width;ctx.fillStyle='rgba(10,27,43,.72)';ctx.fillRect(x-tw/2-5,y-font,tw+10,font+5);ctx.fillStyle='#c9dae7';ctx.fillText(label,x,y);}
 ctx.textAlign='left';ctx.font='600 '+Math.max(15,Math.round(w*.017))+'px system-ui';ctx.fillStyle='#eef5fd';ctx.fillText(state.eye+' · '+(state.visit==='latest'?'Latest scan':'Earlier / selected scan'),28,36);ctx.font=Math.max(11,Math.round(w*.012))+'px system-ui';ctx.fillStyle='#b7c9db';ctx.fillText(state.demo?'FICTIONAL DEMO':compact?(m.kind==='reference'?'REFERENCE CORNEA':m.kind==='native'?'DEVICE CORNEAL COORDINATES':'APPROXIMATE · GAPS RECONSTRUCTED'):m.kind==='reference'?'REFERENCE CORNEA · PATIENT SHAPE UNAVAILABLE':m.kind==='estimated'?'REPORT-DERIVED CORNEA · APPROXIMATE':'DEVICE SURFACE DATA · RECONSTRUCTED GAPS',28,58);
 ctx.font=Math.max(11,Math.round(w*.012))+'px system-ui';ctx.fillText(compact?'Reference eye · '+(original.radius*2).toFixed(1)+' mm source · '+(state.emphasis>1?'relief ×'+state.emphasis:'true scale'):'Reference globe + reconstructed cornea · source region '+(original.radius*2).toFixed(1)+' mm · '+(state.emphasis>1&&m.kind==='estimated'?'elevation deviation ×'+state.emphasis:'equal physical axes'),28,h-26);
 const layer=m.overlays.find(v=>v.id===state.color)||{id:'unavailable',label:'Selected map unavailable',unit:'',min:0,max:0};ctx.fillStyle='#cad7e7';ctx.fillText(compact?(state.coverage?(requestedMap?'Teal: map · amber: interpolation · gray: unavailable':'Teal: shape · amber: fill · gray: reference'):layer.id==='unavailable'?'Selected map unavailable':layer.id==='combined'?'Curvature color + thickness contours':layer.id==='shape'?'Natural eye · clear shell':layer.id==='form'?'Surface shape · shaded cornea':layer.label+' ('+layer.unit+')'):state.coverage?(requestedMap?'TEAL: MAP · AMBER: DISPLAY INTERPOLATION · GRAY: UNAVAILABLE':'TEAL: SOURCE GEOMETRY · AMBER: RECONSTRUCTED · GRAY: REFERENCE'):layer.id==='unavailable'?'SELECTED MAP UNAVAILABLE':layer.id==='combined'?'COLOR: ANTERIOR CURVATURE · WHITE LINES: THICKNESS (µm)':layer.id==='shape'?'NATURAL VIEW · CLEAR CORNEAL SHELL':layer.id==='form'?'SURFACE SHAPE · LIGHT AND CONTOUR FOLLOW THE CORNEA':layer.label.toUpperCase()+' · '+layer.min.toFixed(layer.unit==='D'?1:0)+'–'+layer.max.toFixed(layer.unit==='D'?1:0)+' '+layer.unit,28,h-48);
 if(state.emphasis>1&&m.kind==='estimated'){ctx.fillStyle='#efc981';ctx.font='600 '+Math.max(11,Math.round(w*.014))+'px system-ui';ctx.fillText(compact?'ELEVATION ×'+state.emphasis+' · DISPLAY ONLY':'ELEVATION DEVIATION ×'+state.emphasis+' · VISUAL AID; VALUES UNCHANGED',28,82);}
 if(missing.length){ctx.fillStyle='#bac4ce';ctx.font=Math.round(w*.012)+'px system-ui';ctx.fillText('Gray mesh = reference surface where data are unavailable',28,h-70);}
 // The true-scale section follows the thinnest supported sample, which may
 // be off-center. Original row adjacency prevents joining missing samples.
 const thinnest=original.vertices.filter(v=>v&&finite(v.thickness)).sort((a,b)=>a.thickness-b.thickness)[0],targetY=thinnest?.front[1]??0;
 const sectionY=(original.axisY||[0]).reduce((a,b)=>Math.abs(b-targetY)<Math.abs(a-targetY)?b:a);
 const slice=original.vertices.map((v,i)=>({v,i})).filter(q=>q.v&&Math.abs(q.v.front[1]-sectionY)<1e-7&&Math.hypot(q.v.front[0],q.v.front[1])<=base.displayRadius).sort((a,b)=>a.v.front[0]-b.v.front[0]),sx=w*.71,sy=h*.78,sk=w*.25/(m.radius*2);
 if(!compact&&(!state.eyeContext||state.cut)){ctx.fillStyle='rgba(19,31,49,.92)';ctx.fillRect(sx-16,sy-38,w*.27,h*.17);ctx.fillStyle='#a9bdd3';ctx.font=Math.max(11,Math.round(w*.01))+'px system-ui';ctx.fillText(thinnest?'THINNEST SOURCE ROW · TRUE SCALE':'SOURCE CENTER ROW · TRUE SCALE',sx,sy-20);
 const section=v=>[sx+w*.125+v[0]*sk,sy+30-(v[2]-base.centerZ)*sk];
 for(let i=1;i<slice.length;i++){const a=slice[i-1].v,b=slice[i].v;if(Math.abs(slice[i].i-slice[i-1].i)!==1)continue;
  if(a.back&&b.back){ctx.beginPath();[a.front,b.front,b.back,a.back].map(section).forEach((p,j)=>j?ctx.lineTo(...p):ctx.moveTo(...p));ctx.closePath();ctx.fillStyle='#5c8393';ctx.fill();}
  for(const side of ['front','back'])if(a[side]&&b[side]){ctx.beginPath();ctx.moveTo(...section(a[side]));ctx.lineTo(...section(b[side]));ctx.strokeStyle=side==='front'?'#b4e6f1':'#d4b886';ctx.lineWidth=1.5;ctx.stroke();}
 }}
 const selectedVertex=Number.isInteger(state.selected)?m.vertices.find(v=>v.sourceId===state.selected):null;
 if(selectedVertex){
  const v=selectedVertex,p=project(m,v.front,state,w,h);ctx.strokeStyle='#fff2c9';ctx.lineWidth=2;ctx.beginPath();ctx.arc(p[0],p[1],7,0,Math.PI*2);ctx.stroke();
  if(v.back){const q=project(m,v.back,state,w,h);ctx.setLineDash([3,3]);ctx.beginPath();ctx.moveTo(p[0],p[1]);ctx.lineTo(q[0],q[1]);ctx.stroke();ctx.setLineDash([]);}
 }

 function drawThicknessContours(){
  const segments=thicknessContours(displayMesh(displaySource)),labels=new Set();ctx.font=Math.max(11,w*.012)+'px system-ui';ctx.textAlign='center';
  for(const seg of segments){if(state.cut&&seg.points.some(p=>p[0]>1e-8))continue;const ps=seg.points.map(p=>project(m,p,state,w,h)),mid=ps[0].map((v,k)=>(v+ps[1][k])/2),ix=Math.round(mid[0]),iy=Math.round(mid[1]);if(ix<0||iy<0||ix>=w||iy>=h||mid[2]<zbuf[iy*w+ix]-.025)continue;
   ctx.beginPath();ctx.moveTo(ps[0][0],ps[0][1]);ctx.lineTo(ps[1][0],ps[1][1]);ctx.strokeStyle='rgba(15,31,45,.6)';ctx.lineWidth=3;ctx.stroke();ctx.strokeStyle='#f0fbff';ctx.lineWidth=1.2;ctx.stroke();
   if(!labels.has(seg.level)&&mid[0]>w*.24&&mid[0]<w*.65&&mid[1]>h*.2&&mid[1]<h*.66){labels.add(seg.level);ctx.fillStyle='#102b40';ctx.fillRect(mid[0]-20,mid[1]-13,40,18);ctx.fillStyle='white';ctx.fillText(String(seg.level),mid[0],mid[1]);}
  }
 }
 return {pick,width:w,height:h,state};
}
// A source-only meridian. Missing samples break the section; neither the outer
// anatomical continuation nor color-map fills can manufacture its contour.
function renderSection(canvas,model,options={}){
 const angle=finite(options.angle)?options.angle:S.profileAngle(model),section=S.section(model,angle),factor=model.kind==='estimated'&&finite(options.emphasis)?clamp(options.emphasis,1,6):1;
 const peakOnSection=section.peak&&Math.abs(section.peak.x*Math.sin(angle)-section.peak.y*Math.cos(angle))<1e-7;
 const w=canvas.width,h=canvas.height,ctx=canvas.getContext('2d'),compact=w<650;
 ctx.fillStyle='#101d2e';ctx.fillRect(0,0,w,h);ctx.textAlign='left';ctx.fillStyle='#e0eff7';ctx.font='600 '+(compact?13:15)+'px system-ui';ctx.fillText('SOURCE CROSS-SECTION',24,25);
 ctx.font=(compact?11:12)+'px system-ui';ctx.fillStyle='#afc8dc';ctx.fillText(peakOnSection?'Meridian through highest supported anterior elevation':'Meridian through available source geometry',24,45);
 ctx.fillStyle=factor>1?'#efc981':'#d0e4ee';ctx.font='600 '+(compact?11:12)+'px system-ui';ctx.fillText(factor>1?'ELEVATION DEVIATION ×'+factor+' · DISPLAY ONLY':'TRUE SCALE · EQUAL PHYSICAL AXES',24,64);
 const c=Math.cos(angle),s=Math.sin(angle),pts=section.points.map(p=>{if(!p)return null;const dz=factor>1&&finite(p.elevation)?(factor-1)*p.elevation/1000:0;return {...p,front:[p.distance,p.front[2]+dz],back:p.back?[p.back[0]*c+p.back[1]*s,p.back[2]+dz]:null};});
 const zs=pts.flatMap(p=>p?[p.front[1],...(p.back?[p.back[1]]:[]),...(finite(p.reference_z)?[p.reference_z]:[])]:[]);
 if(!zs.length||model.kind==='reference'){ctx.fillStyle='#b6c9da';ctx.fillText('Patient height data are unavailable for this section.',24,105);return {angle,points:[],factor};}
 const zmin=Math.min(...zs),zmax=Math.max(...zs),left=40,right=w-25,top=82,bottom=h-43,scale=Math.min((right-left)/(2*model.radius+.25),(bottom-top)/(zmax-zmin+.14)),cx=(left+right)/2,cy=(top+bottom)/2,zc=(zmin+zmax)/2;
 const project2=([distance,z])=>[cx+distance*scale,cy-(z-zc)*scale];
 ctx.strokeStyle='rgba(135,165,191,.12)';ctx.lineWidth=1;
 for(let d=-Math.floor(model.radius);d<=model.radius;d++){const x=cx+d*scale;ctx.beginPath();ctx.moveTo(x,top);ctx.lineTo(x,bottom);ctx.stroke();ctx.textAlign='center';ctx.fillStyle='#90aabd';ctx.font='10px system-ui';ctx.fillText(d+' mm',x,bottom+16);}
 ctx.textAlign='left';
 for(let i=1;i<pts.length;i++){const a=pts[i-1],b=pts[i];if(!a||!b)continue;if(a.back&&b.back){ctx.beginPath();[a.front,b.front,b.back,a.back].map(project2).forEach((p,j)=>j?ctx.lineTo(...p):ctx.moveTo(...p));ctx.closePath();ctx.fillStyle='rgba(106,168,190,.25)';ctx.fill();}}
 function line(side,color,dash=[]){ctx.strokeStyle=color;ctx.lineWidth=side==='front'?2.5:1.5;ctx.setLineDash(dash);ctx.beginPath();let open=false;for(const p of pts){const value=p&&(side==='reference'?finite(p.reference_z)?[p.distance,p.reference_z]:null:p[side]);if(!value){open=false;continue;}const q=project2(value);if(open)ctx.lineTo(...q);else ctx.moveTo(...q);open=true;}ctx.stroke();ctx.setLineDash([]);}
 if(model.kind==='estimated')line('reference','#91a1b8',[5,5]);line('back','#d6b786');line('front','#b9edf4');
 if(peakOnSection){const p=S.sample(model,section.peak.x,section.peak.y);if(p){const distance=section.peak.x*c+section.peak.y*s,dz=factor>1&&finite(p.elevation)?(factor-1)*p.elevation/1000:0,q=project2([distance,p.front[2]+dz]);ctx.fillStyle='#f6ddb0';ctx.beginPath();ctx.arc(q[0],q[1],3.5,0,Math.PI*2);ctx.fill();}}
 ctx.font=(compact?10:11)+'px system-ui';ctx.fillStyle='#adc3d4';ctx.fillText(model.kind==='estimated'?(compact?'Blue: front · gold: inner · dashed: assumed BFS':'Blue: source anterior surface · gold: thickness-derived inner surface · dashed: assumed BFS'):'Blue: source anterior surface · gold: available inner surface',24,h-12);
 return {angle,points:section.points,factor,scale};
}
function sharedScales(models){
 const ranges=new Map(),entries=[];
 for(const [index,m]of models.filter(Boolean).entries())for(const l of m.overlays){
  if(!finite(l.min)||!finite(l.max))continue;
  const min=finite(l.dataMin)?l.dataMin:l.min,max=finite(l.dataMax)?l.dataMax:l.max;
  l.dataMin=min;l.dataMax=max;l.min=min;l.max=max;l.sharedScale=false;
  const d=l.definition||m.mapDefinitions?.[l.id]||null,source=l.mapSource||m.mapSource||'unknown',curvature=l.id==='anterior'||l.id==='posterior';
  // A D unit does not make axial, tangential, mean, or unspecified device
  // curvature interchangeable. Image estimates and native values also retain
  // separate provenance. Unknown device definitions need an explicit key.
  const ambiguous=curvature&&(!d?.type||(d.type==='device_reported'&&!d.definition_id));
  const key=JSON.stringify([l.id,source,d,ambiguous?index:null]);
  const r=ranges.get(key);ranges.set(key,r?{min:Math.min(r.min,min),max:Math.max(r.max,max),count:r.count+1}:{min,max,count:1});entries.push([l,key]);
 }
 for(const [l,key]of entries){const r=ranges.get(key);l.min=r.min;l.max=r.max;l.sharedScale=r.count>1;}
 return models;
}
const api={boundedMapDisplay,anatomicalMesh,interactiveMesh,gapReference,emphasizeElevation,thicknessContours,referenceModel,referenceEye,smooth,imageModel,nativeModel,nativeReferenceModel,fromReport,addImageOverlays,prepare,rotate,project,meshFaces,displayMesh,render,renderSection,sharedScales};
if(node){module.exports=api;return;}
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(v,n=1)=>finite(v)?v.toFixed(n):'—';
function mount(el,sets,eye,result,options={}){
 // The same renderer serves the standalone and bilateral views. External
 // controls alter display state only; each eye keeps its own bound sources.
 let visit=options.visit||(sets.find(s=>s.visit==='latest')?'latest':'first');
 let state={yaw:-.15,pitch:-.82,roll:0,zoom:1,eyeContext:true,cut:false,color:'shape',coverage:false,emphasis:1,profile:false,eye,selected:null,...options.initialState};
 state.eye=eye;
 if(options.embedded)el.classList.add('rg-shape-embedded');
 let model=null,error='',drag=null,dead=false,frame=null,picking=null,resizeObserver=null,engine=null,graphicsFailed=false;
 const prepared=new Map(),contourLevels=new WeakMap();
 for(const s of sets){try{if(s.eye!==eye)throw Error('The scan belongs to a different eye.');prepared.set(s,{model:options.preparedModels?.get(s)||fromReport(s)});}catch(e){prepared.set(s,{error:e.message});}}
 if(!options.preparedModels)sharedScales([...prepared.values()].map(v=>v.model));
 const data=()=>sets.find(s=>s.visit===visit);
 const surfaceOnly=()=>state.color==='shape'||state.color==='form';
 const requestedDisplayFill=color=>!['shape','form'].includes(color);
 const scaleText=()=>{
  const relief=state.emphasis>1?'Elevation deviation ×'+state.emphasis+' for display; source values unchanged. ':'True scale. ';
  if(state.coverage)return relief+(surfaceOnly()?'Teal: source-supported geometry · amber: reconstructed gaps · gray: reference anatomy':'Teal: available '+(state.color==='combined'?'anterior curvature map':'source map')+' · amber: local display interpolation · gray: map unavailable / reference anatomy');
  const l=model.overlays.find(v=>v.id===state.color);
  const localFill=model.mapSource==='image'&&requestedDisplayFill(state.color)?' · small label gaps use display interpolation; gray: unavailable':'';
  if(!l)return relief+({'combined':'Curvature + thickness','anterior':'Anterior curvature','posterior':'Posterior curvature','thickness':'Thickness','elevation':'Anterior elevation','posterior_elevation':'Posterior elevation'}[state.color]||'Selected map')+' unavailable for this visit. No substitute measurements are shown.';
  if(l.id==='combined'){const a=model.overlays.find(v=>v.id==='anterior');if(!contourLevels.has(model))contourLevels.set(model,[...new Set(thicknessContours(displayMesh(model)).map(s=>s.level))].sort((a,b)=>a-b));const levels=contourLevels.get(model);return relief+a.label+' '+fmt(a.min)+'–'+fmt(a.max)+' D'+(a.sharedScale?' · shared compatible scale':'')+' · '+(levels.length?'white thickness contours: '+levels.join(', ')+' µm':'no thickness contour within the available range')+localFill;}
  if(surfaceOnly())return relief+(model.kind==='reference'?'Reference cornea; patient shape unavailable.':l.id==='form'?'Light and silhouette follow the reconstructed corneal surface.':'Clear corneal shell over a reference iris.')+(state.cut?' Gold: cut edge.':'');
  return relief+l.label+' · '+fmt(l.min,l.unit==='D'?1:0)+'–'+fmt(l.max,l.unit==='D'?1:0)+' '+l.unit+(l.sharedScale?' · shared compatible scale':'')+' · source map values'+localFill;
 };
 function metrics(){const c=result?.case,values=visit==='latest'?c?.latest:c?.first;if(!values)return '';return '<div class="rg-shape-metrics">'+[['A','A · ARC',2,'mm'],['B','B · PRC',2,'mm'],['C','Thinnest',0,'µm'],['Kmax','Kmax',1,'D'],['BAD_D','BAD-D',2,''],['ARTmax','ARTmax',0,'µm']].map(([key,label,n,u])=>'<div><span>'+label+'</span><strong>'+fmt(values[key],n)+' <small>'+u+'</small></strong></div>').join('')+'</div><p class="rg-small">'+(finite(result?.prediction?.nkpi)?'NKPI '+result.prediction.nkpi.toFixed(1)+' / 100 · ':'')+'These are the calculator’s confirmed summary values. They do not each have a point-by-point spatial map.</p>';}
 function details(){
  const source=model.kind==='reference'?esc(model.referenceReason||'Patient anterior heights are unavailable.')+' The front is a reference sphere. Available map values keep their own locations; they do not generate a cone.':model.kind==='estimated'?'The printed anterior elevation and BFS radius ('+fmt(model.bfs,2)+' mm) shape the supported cornea. The report does not supply the reference sphere’s full position and tilt, so this reconstruction is approximate. '+(model.thicknessRange?'Readable pachymetry offsets the inner boundary along the reconstructed anterior normal.':'Pachymetry is unavailable; the inner presentation shell is reference anatomy and has no thickness readout.'):'Supported anterior and posterior coordinates retain the supplied device heights and declared orientation. Device pachymetry remains a separate measurement; it is not replaced by vertical front/back separation. Missing posterior heights can use a thickness-derived offset for presentation.';
  return '<details class="rg-details"><summary>Reconstruction &amp; source coverage</summary><p>'+source+'</p><p>The white globe, blue iris, pupil and unmeasured peripheral cornea are reference anatomy. They supply visual context and are not fitted to the patient. The clear cornea follows the available surface geometry, with lighting and reflections for depth. These visual effects do not simulate the patient’s optics.</p><p>Small unreadable image areas use local-plane interpolation. Remaining geometric gaps use smooth continuation while retaining supported source heights. <b>Source coverage</b> shows the selected field’s support. For a quantitative map, teal marks available source values, amber marks local display interpolation, and gray marks unavailable values or reference anatomy. The combined view shows anterior-curvature map support. For <b>Natural eye</b> and <b>Surface shape</b>, the colors instead distinguish source-supported geometry (teal), geometric gap completion (amber), and reference anatomy (gray). '+(model.kind==='reference'?'The reference surface is complete by construction.':Math.round(model.coverage*100)+'% of the sampled source grid supports this reconstruction, including local interpolation.')+' This percentage describes coverage, not accuracy. Gap completion adds no patient measurements and does not affect NKPI, regional change or cone tracking.</p><p>The bilateral view starts with <b>Curvature + thickness</b> when both fields are available. <b>Natural eye</b> shows the clear corneal shell. <b>Surface shape</b> uses solid shading to make small contour changes easier to inspect. <b>Eye detail</b> frames the corneal dome with its iris and globe. <b>Shape profile</b> adds an orthographic side view and a source-only meridian through the highest supported anterior elevation, or the thinnest supported location when elevation is absent. This inspection point is not a validated cone apex. Missing source samples break the plotted section.</p><p>All axes use the same physical units. Whole eye uses mild perspective in WebGL; the Canvas fallback, Eye detail and profile use orthographic projection. The optional ×3 and ×6 settings amplify only report-image elevation deviation for display and move front/inner coordinates together. Source heights, pachymetry, map values and calculations remain unchanged. Amplification is labeled in the view and saved figure; native device heights are not amplified.</p><p>Quantitative colors follow the selected source field. Small image-label gaps may receive bounded display interpolation; large gaps remain gray and interpolated colors add no numerical readout. Lighting does not change their scale. White thickness contours use supported source triangles. Posterior maps appear on the outer shell for location comparison; they do not replace anterior geometry. Earlier and latest shapes are independent reconstructions, not a registered deformation or elevation subtraction.</p><p>For the closest supported corneal reconstruction, import native anterior/posterior coordinates and device pachymetry using the documented coordinate contract in docs/SURFACE_DATA.md. Report images alone cannot establish a 1:1 patient replica.</p></details>';
 }
 function syncControls(){
  const set=(selector,key,value)=>{const node=el.querySelector(selector);if(node)node[key]=value;};
  set('[data-shape-context]','value',state.eyeContext?'eye':'cornea');
  set('[data-shape-color]','value',state.color);
  set('[data-shape-cut]','checked',state.cut);
  set('[data-shape-coverage]','checked',state.coverage);
  set('[data-shape-emphasis]','value',String(state.emphasis));
  const profile=el.querySelector('[data-shape-view="profile"]');if(profile)profile.setAttribute('aria-pressed',String(state.profile));
 }
 function sourceLabel(){return model?.kind==='reference'?(data()?'Reference shape · available patient maps':'No scan linked · reference anatomy'):model?.kind==='estimated'?'Approximate report-image cornea':'Device corneal coordinates · true scale';}
 function notifyCamera(){if(!dead&&typeof options.onViewChange==='function')options.onViewChange({yaw:state.yaw,pitch:state.pitch,roll:state.roll,zoom:state.zoom,eyeContext:state.eyeContext,profile:state.profile});}
 function applyView(view){
  state.profile=view==='profile'&&model?.kind!=='reference';state.zoom=options.embedded ? .88 : 1;state.roll=0;
  state.yaw=view==='reset'?(state.eyeContext?-.30:-.5):view==='profile'?-1.48:0;
  state.pitch=view==='reset'?(state.eyeContext?-.18:-.2):0;
  if(view==='profile'){state.eyeContext=false;state.cut=false;if(state.profile)state.roll=-Math.PI/2-S.profileAngle(model);}
 }
 function layout(){
  if(engine){engine.dispose();engine=null;}
  if(resizeObserver){resizeObserver.disconnect();resizeObserver=null;}
  try{const current=data(),entry=prepared.get(current);if(entry?.error)throw Error(entry.error);model=entry?.model||referenceModel([]);if(!current)model.referenceReason='No verified scan is linked to this eye yet.';error='';}catch(e){model=null;error=e.message;}
  state.selected=null;
  if(!options.embedded&&model&&!model.overlays.some(l=>l.id===state.color))state.color='shape';
  if(model?.kind!=='estimated')state.emphasis=1;
  if(model?.kind==='reference')state.profile=false;
  if(model&&state.profile)state.roll=-Math.PI/2-S.profileAngle(model);
  el.innerHTML=options.embedded?'':'<div class="rg-shape-toolbar"><div class="rg-actions">'+sets.map(s=>'<button type="button" data-shape-visit="'+s.visit+'" aria-pressed="'+(s.visit===visit)+'">'+(s.visit==='latest'?'Latest scan':sets.length>1?'Earlier scan':'Selected scan')+'</button>').join('')+'</div></div>';
  if(!model){el.innerHTML+='<p class="rg-empty-small">'+esc(error)+' The original report remains available below.</p>';return;}
  el.innerHTML+=(options.embedded?'<div class="rg-shape-source" data-shape-source>'+esc(sourceLabel())+' · '+(data()?'Source field '+fmt(model.radius*2)+' mm':'No patient measurements')+'</div>':'<div class="rg-shape-label"><div><b>Anatomical eye · '+eye+'</b><span>'+(model.kind==='reference'?(data()?'Reference shape · available patient maps':'Reference eye · no scan linked'):model.kind==='estimated'?'Report-derived cornea · approximate':'Device corneal coordinates · true scale')+'</span></div><span>'+(data()?'Source field '+fmt(model.radius*2)+' mm · ':'')+'Reference globe and iris</span></div>'+
   '<div class="rg-shape-toolbar"><label>View <select data-shape-context><option value="cornea">Eye detail</option><option value="eye">Whole eye</option></select></label><label>Show <select data-shape-color>'+model.overlays.map(l=>'<option value="'+l.id+'">'+l.label+'</option>').join('')+'</select></label><div class="rg-actions"><button type="button" data-shape-view="reset">3D</button><button type="button" data-shape-view="front">Front</button><button type="button" data-shape-view="profile"'+(model.kind==='reference'?' disabled title="Requires patient height data"':'')+'>Shape profile</button></div><label><input type="checkbox" data-shape-cut> Tissue cutaway</label><label><input type="checkbox" data-shape-coverage> Source coverage</label>'+
   (model.kind==='estimated'?'<label>Elevation relief <select data-shape-emphasis><option value="1">True scale</option><option value="3">×3 · display only</option><option value="6">×6 · display only</option></select></label>':'')+'</div>'+
   '<p class="rg-shape-hint">The clear cornea sits over the iris. Drag the eye to inspect its contour, or choose a map under <b>Show</b>. <b>Shape profile</b> opens a side view and source cross-section.</p>')+
   '<div class="rg-shape-stage"><canvas data-shape-main width="1000" height="680" tabindex="0" aria-label="'+eye+' corneal 3D surface. Drag or arrow keys to rotate. Plus and minus zoom. Click to inspect a surface sample."></canvas><div class="rg-shape-controls"><span>Drag to rotate · click to inspect</span><button type="button" data-shape-zoom="out" aria-label="Zoom out">−</button><button type="button" data-shape-zoom="in" aria-label="Zoom in">+</button></div></div>'+
   '<div class="rg-shape-section" data-shape-section hidden><canvas width="1000" height="340" aria-label="Corneal source cross-section; gaps remain unconnected"></canvas><p>Source samples only. The gold point marks the highest supported anterior elevation when available. It is not a validated cone apex. The section follows the selected, labeled relief setting.</p></div>'+
   '<div class="rg-shape-scale" data-shape-scale></div><div class="rg-shape-pick" data-shape-pick role="status">Select the cornea to inspect a sample. Reference anatomy has no patient measurements.</div>'+(options.embedded?'':metrics())+
   (options.embedded?'':'<div class="rg-shape-toolbar"><span class="rg-small">Globe, iris and unmeasured periphery are reference anatomy. Reconstruction status is shown above.</span><button type="button" data-shape-save>Save figure</button></div>'+details());
  syncControls();
  let canvas=el.querySelector('[data-shape-main]');
  if(!graphicsFailed&&root.NKPIAnatomicalEye){try{engine=new root.NKPIAnatomicalEye(canvas,{shapeAPI:api});if(!engine.available)throw Error('WebGL unavailable');}catch(e){if(engine)engine.dispose();engine=null;graphicsFailed=true;const fresh=canvas.cloneNode(false);canvas.replaceWith(fresh);canvas=fresh;}}
  canvas.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY};canvas.setPointerCapture(e.pointerId);});
  canvas.addEventListener('pointermove',e=>{if(!drag)return;state.yaw+=(e.clientX-drag.x)*.008;state.pitch=clamp(state.pitch+(e.clientY-drag.y)*.008,-1.55,1.55);drag.x=e.clientX;drag.y=e.clientY;notifyCamera();request();});
  canvas.addEventListener('pointerup',e=>{if(drag&&Math.hypot(e.clientX-drag.startX,e.clientY-drag.startY)<5&&picking){const r=canvas.getBoundingClientRect(),x=Math.floor((e.clientX-r.left)*canvas.width/r.width),y=Math.floor((e.clientY-r.top)*canvas.height/r.height),idx=picking.pickAt?picking.pickAt(x,y):picking.pick[y*canvas.width+x];state.selected=Number.isInteger(idx)&&idx>=0?idx:null;inspect();}drag=null;request();});
  canvas.addEventListener('pointercancel',()=>{drag=null;request();});
  canvas.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','+','-','=','Escape'].includes(e.key))return;e.preventDefault();if(e.key==='ArrowLeft')state.yaw-=.1;if(e.key==='ArrowRight')state.yaw+=.1;if(e.key==='ArrowUp')state.pitch=clamp(state.pitch-.1,-1.55,1.55);if(e.key==='ArrowDown')state.pitch=clamp(state.pitch+.1,-1.55,1.55);if(e.key==='+'||e.key==='=')state.zoom=clamp(state.zoom*1.12,.6,1.8);if(e.key==='-')state.zoom=clamp(state.zoom/1.12,.6,1.8);if(e.key==='Escape'){state.selected=null;inspect();}else notifyCamera();request();});
  canvas.addEventListener('wheel',e=>{e.preventDefault();state.zoom=clamp(state.zoom*Math.exp(-e.deltaY*.001),.6,1.8);notifyCamera();request();},{passive:false});
  let observedWidth=0;if(typeof ResizeObserver!=='undefined'){resizeObserver=new ResizeObserver(()=>{const w=canvas.getBoundingClientRect().width;if(Math.abs(w-observedWidth)>1){observedWidth=w;request();}});resizeObserver.observe(canvas);}draw();
 }
 function draw(){
  frame=null;if(dead||!model)return;
  const canvas=el.querySelector('[data-shape-main]'),cssWidth=Math.max(320,Math.round(canvas.getBoundingClientRect().width||1000)),ratio=options.embedded?1:cssWidth<600?1.08:.68;
  canvas.width=drag?Math.max(320,Math.round(cssWidth*.7)):Math.min(1100,cssWidth);canvas.height=Math.round(canvas.width*ratio);
  try{picking=engine?engine.render(model,{...state,visit,interactive:!!drag}):render(canvas,model,{...state,visit,interactive:!!drag});if(!picking)throw Error('Renderer unavailable');}catch(e){if(engine){engine.dispose();engine=null;graphicsFailed=true;layout();return;}throw e;}
  const panel=el.querySelector('[data-shape-section]');panel.hidden=!state.profile;
  if(state.profile){const profile=panel.querySelector('canvas');profile.width=canvas.width;profile.height=Math.round(Math.max(245,canvas.width*.34));renderSection(profile,model,{emphasis:state.emphasis});}
  syncControls();
  const scale=el.querySelector('[data-shape-scale]');scale.textContent=scaleText();
  if(!surfaceOnly()&&!state.coverage&&model.overlays.some(v=>v.id===state.color)&&model.overlays.some(v=>v.id===(state.color==='combined'?'anterior':state.color))){const id=state.color==='combined'?'anterior':state.color,l=model.overlays.find(v=>v.id===id),bar=document.createElement('i'),stops=id==='thickness'?[0,.5,1]:[0,1/3,2/3,1];bar.className='rg-shape-gradient';bar.style.background='linear-gradient(90deg,'+stops.map(t=>'rgb('+paletteColor(model,id,l.min+(l.max-l.min)*t).map(Math.round).join(',')+') '+(t*100)+'%').join(',')+')';scale.prepend(bar);}
 }
 function request(){if(frame===null)frame=requestAnimationFrame(draw);}
 function inspect(){const node=el.querySelector('[data-shape-pick]'),v=model?.vertices[state.selected];if(!v){node.textContent='Reconstructed or reference area: no source measurement here. Select a source-supported corneal region.';return;}const [x,y]=v.front,side=x>0?(eye==='OD'?'nasal':'temporal'):(eye==='OD'?'temporal':'nasal');node.innerHTML='<b>'+fmt(Math.abs(x),2)+' mm '+side+' · '+fmt(Math.abs(y),2)+' mm '+(y>=0?'superior':'inferior')+'</b><span>'+model.overlays.filter(l=>!['shape','form','combined'].includes(l.id)).map(l=>l.label+': '+(finite(v[l.id])?(model.mapSource==='image'?'~':'')+fmt(l.id==='posterior'?Math.abs(v[l.id]):v[l.id],l.unit==='D'?1:0)+' '+l.unit:'unavailable')).join(' · ')+'</span>';}
 function exportCanvas(){
  if(!model||dead)return null;
   draw();let figure=el.querySelector('[data-shape-main]');
   if(state.profile){const profile=el.querySelector('[data-shape-section] canvas'),combined=document.createElement('canvas');combined.width=figure.width;combined.height=figure.height+profile.height;const ctx=combined.getContext('2d');ctx.drawImage(figure,0,0);ctx.drawImage(profile,0,figure.height);figure=combined;}
   const labeled=document.createElement('canvas'),pad=20,font=Math.max(12,Math.round(figure.width*.016));labeled.width=figure.width;const ctx=labeled.getContext('2d');ctx.font=font+'px system-ui';
   const lines=['NKPI 9.0.9 · '+eye+' · '+(!data()?'No scan linked':visit==='latest'?'Latest scan':'Earlier / selected scan')+' · '+(model.kind==='native'?'Device corneal coordinates':model.kind==='estimated'?'Approximate report-image reconstruction':'Reference corneal shape'),'Reference globe and iris · '+(state.emphasis>1?'Elevation relief ×'+state.emphasis+' for display only':'Unamplified geometry; equal x/y/z units')+' · '+(state.eyeContext&&engine?'Perspective camera':'Orthographic camera'),scaleText()],rows=[];
   for(const line of lines){let text='';for(const word of line.split(' ')){const next=text?text+' '+word:word;if(ctx.measureText(next).width>labeled.width-pad*2&&text){rows.push(text);text=word;}else text=next;}rows.push(text);}
   labeled.height=figure.height+pad*2+Math.ceil(rows.length*font*1.4);ctx.fillStyle='#0d1526';ctx.fillRect(0,0,labeled.width,labeled.height);ctx.drawImage(figure,0,0);ctx.fillStyle='#e2e9f3';ctx.font=font+'px system-ui';let y=figure.height+pad+font;for(const row of rows){ctx.fillText(row,pad,y);y+=font*1.4;}
  return labeled;
 }
 function click(e){
  const b=e.target.closest('button');if(!b)return;
  if(b.dataset.shapeVisit){visit=b.dataset.shapeVisit;layout();}
  else if(b.dataset.shapeView){applyView(b.dataset.shapeView);notifyCamera();request();}
  else if(b.dataset.shapeZoom){state.zoom=clamp(state.zoom*(b.dataset.shapeZoom==='in'?1.15:1/1.15),.6,1.8);notifyCamera();request();}
  else if(b.hasAttribute('data-shape-save')&&model){
   const labeled=exportCanvas(),a=document.createElement('a');a.href=labeled.toDataURL('image/png');a.download='NKPI_'+eye+'_'+visit+'_cornea_'+model.kind+(state.emphasis>1?'_relief_x'+state.emphasis:'_true_scale')+'.png';a.click();
  }
 }
 function change(e){
  if(e.target.hasAttribute('data-shape-context')){state.eyeContext=e.target.value==='eye';state.yaw=-.5;state.pitch=-.2;state.roll=0;state.zoom=1;state.profile=false;}
  else if(e.target.hasAttribute('data-shape-color'))state.color=e.target.value;
  else if(e.target.hasAttribute('data-shape-emphasis'))state.emphasis=Number(e.target.value);
  else if(e.target.hasAttribute('data-shape-coverage'))state.coverage=e.target.checked;
  else if(e.target.hasAttribute('data-shape-cut')){state.cut=e.target.checked;if(state.cut){state.yaw=-1.05;state.pitch=-.10;state.roll=0;state.profile=false;}}
  else return;notifyCamera();request();
 }
 el.addEventListener('click',click);el.addEventListener('change',change);layout();
 const dispose=()=>{dead=true;if(engine)engine.dispose();if(resizeObserver)resizeObserver.disconnect();if(frame!==null)cancelAnimationFrame(frame);el.removeEventListener('click',click);el.removeEventListener('change',change);};
 dispose.getState=()=>({...state,visit});
 dispose.getModel=()=>model;
 dispose.getCanvas=()=>el.querySelector('[data-shape-main]');
 dispose.draw=()=>{if(!dead)draw();};
 dispose.exportCanvas=exportCanvas;
 dispose.getInfo=()=>({visit,kind:model?.kind||null,mapSource:model?.mapSource||null,overlays:model?.overlays.map(l=>({...l}))||[],availableVisits:sets.map(s=>s.visit),hasData:!!data(),hasGeometry:!!model&&model.kind!=='reference',sourceDiameterMm:model?model.radius*2:null,scaleText:model?scaleText():error,sourceLabel:sourceLabel(),supported:!!model?.overlays.some(l=>l.id===state.color)});
 dispose.setVisit=next=>{if(dead||!['first','latest'].includes(next)||next===visit)return;visit=next;layout();};
 dispose.setState=(patch={},control={silent:true})=>{
  if(dead)return;
  const nextVisit=patch.visit;for(const key of ['yaw','pitch','roll','zoom'])if(finite(patch[key]))state[key]=key==='pitch'?clamp(patch[key],-1.55,1.55):key==='zoom'?clamp(patch[key],.6,1.8):patch[key];
  for(const key of ['eyeContext','cut','coverage'])if(typeof patch[key]==='boolean')state[key]=patch[key];
  if(typeof patch.color==='string')state.color=patch.color;
  if(finite(patch.emphasis))state.emphasis=model?.kind==='estimated'?clamp(patch.emphasis,1,6):1;
  if(patch.profile===false){state.profile=false;state.roll=0;}
  if(patch.profile===true||patch.view==='profile')applyView('profile');
  else if(['front','reset'].includes(patch.view))applyView(patch.view);
  if(['first','latest'].includes(nextVisit)&&nextVisit!==visit){visit=nextVisit;layout();}else request();
  if(control.silent===false)notifyCamera();
 };
 return dispose;
}
root.NKPIPatientShape={...api,mount};
})(typeof window!=='undefined'?window:globalThis);
