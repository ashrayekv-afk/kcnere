'use strict';
// Engineering fixtures; these checks do not establish clinical accuracy.
const assert=require('node:assert/strict');
const M=require('../components/cornea/integrated_measurements.js');
let count=0;
const test=(name,fn)=>{fn();count++;console.log('PASS '+name);};
const close=(a,b)=>assert(Math.abs(a-b)<1e-9,`${a} != ${b}`);
const vertex=(x,y,thickness,fields={})=>({front:[x,y,-.1*(x*x+y*y)],back:null,thickness,...fields});
function model(eye='OD',visit='latest',kind='native'){
 return {eye,visit,kind,mapSource:kind==='native'?'native':'image',sourceKind:kind==='native'?'native':'report-image',
  hasPatientGeometry:true,fit_diameter:8,mapDefinitions:{
   thickness:{type:'device_pachymetry',definition_id:'fixture-a'},
   anterior:{type:'axial',definition_id:'fixture-a'},
   posterior:{type:'axial',definition_id:'fixture-a'},
   elevation:{type:'best_fit_sphere',fit_diameter_mm:8,definition_id:'fixture-a'},
   posterior_elevation:{type:'best_fit_sphere',fit_diameter_mm:8,definition_id:'fixture-a'}},
  vertices:[vertex(0,0,510,{anterior:44,posterior:-6,elevation:5,posterior_elevation:-12}),
   vertex(1,-1,450,{anterior:50,posterior:-8,elevation:30,posterior_elevation:26}),
   vertex(-1,1,525,{anterior:42,posterior:-5,elevation:-18,posterior_elevation:-20})]};
}
function freeze(value){if(value&&typeof value==='object'){Object.freeze(value);for(const child of Object.values(value))freeze(child);}return value;}

test('Default point uses the smallest available pachymetry away from the center',()=>{
 const source=model(),picked=M.findThinnest(source);
 assert.equal(picked.index,1);assert.equal(picked.thickness,450);assert.equal(picked.x,1);assert.equal(picked.y,-1);
 assert.equal(picked.scope,'available-mapped-samples');assert.equal(picked.label,'Lowest mapped pachymetry');
 assert.equal(picked.approximate,false);assert.equal(picked.geometryAvailable,true);
});
test('A thinner point wins even when every other measurement and inner boundary is missing',()=>{
 const source=model();source.vertices[2]=vertex(-2,-1,420);
 const picked=M.findThinnest(source);assert.equal(picked.index,2);assert.equal(picked.thickness,420);
 assert.equal(source.vertices[2].back,null);
});
test('Null, nonfinite, nonpositive and unsupported samples never become a minimum',()=>{
 const source=model();source.vertices=[null,vertex(0,0,null),vertex(0,0,0),vertex(0,0,-20),vertex(0,0,NaN),
  vertex(0,0,Infinity),{front:[0,NaN,0],thickness:80},
  vertex(0,0,90,{provenance:'filled'}),vertex(0,0,95,{supported:false}),vertex(1,0,460)];
 assert.equal(M.findThinnest(source).index,9);
 source.vertices.pop();source.C=315;assert.equal(M.findThinnest(source),null);
 assert.equal(M.findThinnest(null),null);
});
test('Ties resolve by physical central distance, then original source index',()=>{
 const source=model();source.vertices=[vertex(2,0,460),vertex(1,0,460),vertex(0,1,460),vertex(0,0,470)];
 assert.equal(M.findThinnest(source).index,1);
 source.vertices[2].thickness=459.999999999;assert.equal(M.findThinnest(source).index,2);
});
test('Estimated and native map-only minima retain their explicit scope without inventing patient heights',()=>{
 const image=model('OD','latest','estimated'),mapped=M.findThinnest(image);assert.equal(mapped.approximate,true);
 const reference=model();reference.kind='reference';reference.sourceKind='reference';reference.hasPatientGeometry=false;
 const selected=M.findThinnest(reference);assert.equal(selected.thickness,450);assert.equal(selected.approximate,false);
 assert.equal(selected.geometryAvailable,false);assert.equal(selected.scope,'available-mapped-samples');
});
test('Selection, ranges, grouping and colors do not mutate frozen native or report models',()=>{
 const sources=[model(),model('OS','first','estimated')],before=JSON.stringify(sources);sources.forEach(freeze);
 const ranges=M.sharedScales(sources);
 for(const source of sources){M.findThinnest(source);for(const field of M.FIELDS){M.getFieldRange(source,field);M.rangeSignature(source,field);M.colorAt(field,500,ranges.get(source)[field]);}}
 assert.equal(JSON.stringify(sources),before);
});
test('Field ranges keep signed elevations, positive thickness and posterior curvature magnitudes',()=>{
 const source=model();source.vertices.push(vertex(0,2,0,{posterior:-10,elevation:-40}));
 assert.deepEqual(M.getFieldRange(source,'thickness'),{min:450,max:525,count:3});
 assert.deepEqual(M.getFieldRange(source,'posterior'),{min:5,max:10,count:4});
 assert.deepEqual(M.getFieldRange(source,'elevation'),{min:-40,max:30,count:4});
 assert.equal(M.getFieldRange(source,'shape'),null);assert.equal(M.getFieldRange(null,'thickness'),null);
});
test('Compatible eye and visit scales remain fixed under source order and active-view changes',()=>{
 const odFirst=model('OD','first'),odLatest=model('OD','latest'),osLatest=model('OS','latest');
 odFirst.vertices[0].thickness=600;osLatest.vertices[1].thickness=390;
 const source=[odFirst,odLatest,osLatest],before=JSON.stringify(source),a=M.sharedScales(source),b=M.sharedScales([...source].reverse());
 for(const m of source){assert.deepEqual(a.get(m).thickness,b.get(m).thickness);assert.equal(a.get(m).thickness.dataMin,390);
  assert.equal(a.get(m).thickness.dataMax,600);assert(a.get(m).thickness.sharedAcrossEyes);assert(a.get(m).thickness.sharedAcrossVisits);
  assert.equal(a.get(m).thickness.sourceCount,3);}
 assert.deepEqual(a.get(odFirst).thickness,a.get(odLatest).thickness);assert.equal(JSON.stringify(source),before);
});
test('Different source types, curvature definitions and reference diameters retain separate scales',()=>{
 const native=model(),image=model('OS','latest','estimated'),tangent=model('OS'),differentFit=model('OS');
 image.vertices[0].anterior=75;tangent.mapDefinitions.anterior.type='tangential';tangent.vertices[0].anterior=90;
 differentFit.mapDefinitions.elevation.fit_diameter_mm=7;differentFit.vertices[0].elevation=100;
 const scales=M.sharedScales([native,image,tangent,differentFit]);
 assert.equal(scales.get(native).anterior.dataMax,50);assert.equal(scales.get(image).anterior.dataMax,75);
 assert.equal(scales.get(tangent).anterior.dataMax,90);assert.equal(scales.get(native).elevation.dataMax,30);
 assert.equal(scales.get(differentFit).elevation.dataMax,100);
});
test('Canonical definitions ignore key order and support-only metadata but unknown device types do not merge',()=>{
 const a=model(),b=model('OS');b.mapDefinitions.posterior_elevation={partial:true,definition_id:'fixture-a',fit_diameter_mm:8,type:'best_fit_sphere'};
 assert.equal(M.rangeSignature(a,'posterior_elevation'),M.rangeSignature(b,'posterior_elevation'));
 a.mapDefinitions.anterior={type:'device_reported'};b.mapDefinitions.anterior={type:'device_reported'};
 assert.notEqual(M.rangeSignature(a,'anterior'),M.rangeSignature(b,'anterior'));
 assert.equal(M.rangeSignature(a,'anterior'),M.rangeSignature(a,'anterior'));
 a.mapDefinitions.anterior.definition_id=b.mapDefinitions.anterior.definition_id='known-device-map';
 assert.equal(M.rangeSignature(a,'anterior'),M.rangeSignature(b,'anterior'));
});
test('Every scale contains its inputs and has five evenly spaced ticks matching contour positions',()=>{
 const cases=[['thickness',341,642],['anterior',39.9,67.8],['posterior',4.2,9.1],['elevation',-62,31],
  ['posterior_elevation',2,53],['thickness',500,500],['anterior',48,48],['posterior_elevation',0,0]];
 for(const [field,min,max]of cases){const scale=M.makeScale(field,{min,max});assert(scale);assert(scale.min<=min&&scale.max>=max);
  assert.equal(scale.ticks.length,5);assert.equal(scale.ticks[0],scale.min);assert.equal(scale.ticks[4],scale.max);
  scale.ticks.forEach((tick,i)=>close((tick-scale.min)/(scale.max-scale.min),i/4));
  assert.deepEqual(M.contourLevels(scale),scale.ticks.slice(1,4));
  if(field.endsWith('elevation')||field==='elevation'){assert.equal(scale.min,-scale.max);assert.equal(scale.ticks[2],0);close(M.normalize(field,0,scale),.5);}
 }
 assert.equal(M.makeScale('thickness',{min:20,max:10}),null);assert.equal(M.makeScale('shape',{min:0,max:1}),null);
});
test('One shared palette function matches all five legend stops and opposite thickness/curvature directions',()=>{
 const bounds={min:0,max:100};
 for(const field of ['anterior','posterior','elevation','posterior_elevation']){
  const stops=M.paletteStops(field);assert.equal(stops.length,5);
  stops.forEach((color,i)=>assert.deepEqual(M.colorAt(field,i*25,bounds),color));
  assert(stops.flat().every(channel=>channel>=0&&channel<=1));
 }
 const thicknessScale={min:300,max:700};
 assert.deepEqual(M.colorAt('thickness',300,thicknessScale),M.paletteStops('anterior')[4]);
 assert.deepEqual(M.colorAt('thickness',700,thicknessScale),M.paletteStops('anterior')[0]);
 assert.deepEqual(M.colorAt('posterior',-50,bounds),M.colorAt('posterior',50,bounds));
 const signed=M.makeScale('elevation',{min:-70,max:20});assert.deepEqual(M.colorAt('elevation',0,signed),M.paletteStops('elevation')[2]);
 assert.equal(M.colorAt('thickness',null,thicknessScale),null);assert.equal(M.colorAt('thickness',0,thicknessScale),null);
 const copy=M.paletteStops('anterior');copy[0][0]=99;assert(M.paletteStops('anterior')[0][0]<1);
});
console.log(`${count} integrated measurement-display checks passed.`);
