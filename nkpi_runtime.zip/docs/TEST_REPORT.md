# Version 9.1.1 software verification — 27 October 2026

This is a display and point-selection update to 9.1.0. It starts each eye at its lowest available mapped pachymetry and provides opaque measurement colors, numeric legends, stable compatible scales, contour lines and a front-facing Map view. The natural-eye appearance and all five independent measurement fields remain available.

## Preserved calculation, extraction and geometry

The release builder compares every previous source file against the completed 9.1.0 manifest. Only the integrated viewer/style, its HTML loading order, documentation and prescribed version identifiers may change. Two new files supply the pure measurement helper and its tests.

All OCR readers, OCR libraries and language models, source calibration, native surface schema, reconstruction geometry, regional comparisons, trained models, coefficients and dependency declarations remain byte-identical. Python files differ only in the UI version and Streamlit component identity. No image parser, source grid, smoothing rule or anatomical coordinate was changed for this release.

Four representative complete OD/OS calculator outputs across baseline and longitudinal modes match 9.1.0 after excluding `ui_version`. This is a scoped regression check; the prior release's complete calculator validation remains documented in that release.

The original-report browser OCR results used for display testing were produced and verified in 9.1.0. This release reuses those unchanged extracted data. It does not claim a new OCR accuracy study or repeat the source-image reading benchmark.

## Minimum selection

The new measurement-helper suite has **12 passing checks**. It verifies:

- A minimum away from the center becomes the initial selection.
- A thinner point wins even when other measurement fields or its inner boundary are unavailable.
- Missing, nonfinite, zero, negative, unsupported and explicitly fabricated presentation samples are excluded.
- Equal values use deterministic distance-from-center and source-index tie breaks.
- Native and image-derived models remain unchanged, including frozen inputs.
- A native map-only minimum retains its available values without acquiring invented patient heights.
- Signed elevation and posterior curvature magnitude conventions remain intact.
- Compatible eyes and visits receive the same scale regardless of input order or the active view.
- Different source types, curvature definitions and elevation fitting diameters stay separate.
- Unknown device curvature definitions cannot share a scale without an explicit common definition identifier.
- Five evenly spaced ticks enclose the supported values; signed elevation is centered on zero.
- One palette specification supplies both renderers and the legend.

The initial point is labeled **Lowest mapped pachymetry**. It is a minimum of the available supported samples, not a replacement for the device's printed scalar C or a claim that all corneal locations were measured. Image-derived geometry and thickness retain the previous color-resolution and local-fitting limits.

## Source cases and missing-data behavior

The supplied bilateral report maps exercise different completeness patterns. The lowest readable left-eye thickness sample is isolated from retained triangles because neighboring cells are unavailable. The viewer preserves that lower value and its source position. It uses a point-only marker, labels the surrounding surface unavailable and does not substitute a thicker connected point or create a tissue patch.

A minimum need not have every other field available at the same coordinate. Missing curvature or elevation remains unavailable. Neither maximum curvature nor maximum elevation is assumed to coincide with minimum pachymetry.

The Section boundary follows the radial direction of the eye/visit's mapped minimum. Its retained triangles and walls use original source coordinates. A manually selected location inside the viewing cut is distinguished from a source-data gap; Whole surface can reveal the former but cannot repair the latter.

## Focused browser acceptance

The viewer passed **32 focused browser groups: 16 in WebGL and 16 in Canvas fallback**, with no uncaught page errors or external requests. These checks exercise actual production modules, valid synthetic native fixtures and the previously extracted supplied report maps. They cover minimum selection/reset, independent eye/visit state, manual selections across map changes, stable numerical scales, active-field callouts, missing values, native pachymetry, map-only inputs, source immutability and PNG export.

Measurement-mode callouts identify the active field and its units. Curvature and elevation use point labels; only supported thickness-derived boundaries use a thickness-distance caliper. Natural eye and Thickness retain their pachymetry annotation. The selected point marker uses the same viewport projection as the rendered surface.

Quantitative WebGL colors are opaque and unlit. The Canvas fallback paints quantitative triangles using per-pixel barycentric interpolation and depth, avoiding dark seams from separately antialiased polygon fills. Pixel checks compare rendered colors with the common palette and check that camera rotation does not introduce lighting-based value changes. Missing numerical data are gray; missing geometry remains absent.

Contours follow the three interior numerical scale levels. They do not change source values, color bounds, geometry or selection. A Map view action switches to whole/front; from Natural eye it opens Thickness when available or another available measurement, while an already selected measurement stays selected.

The combined PNG includes both eyes, the active map, numerical scale and units, selected values, minimum-selection status and source limitations. This release contains no source report images, extracted patient arrays or QA screenshots.

## Application layout and packaging gates

The packaged Streamlit component passed **eight application and layout groups**, including its inherited calculator styles. Desktop and phone widths (1280, 390 and 320 pixels) were checked for button state, legend readability, control fit, canvas gestures, explicit OD/OS numerical separation and horizontal overflow. Original parsed maps linked through the existing source protocol; edited inputs and next-patient clearing retained their prior behavior. No uncaught page errors, external requests or failed requests were recorded.

The five-file GitHub upload layout remains unchanged. The runtime contains **126 files**, including a manifest of **125 source entries**. The clean candidate package passed exact ZIP membership, CRC integrity, source hashes/sizes, matching launcher checksum, all **40 local HTML asset references** and the new helper's loading order. The extracted launcher started from a different working directory. Baseline and longitudinal OD/OS assessment events produced scores and valid PDF headers; all four representative complete eye results remained identical to 9.1.0. The final archive is checked again after documentation updates.

All five individual upload files remain below 25 MiB. The launcher, OCR runtime and Python dependency versions are retained. The app identifies itself as `9.1.1-thinnest-maps` with the `v9_1_1` Streamlit component identity.

## Scope and limits

These are software checks, not clinical validation. A readable color map cannot recover values hidden by clipping, missing source regions or print resolution. The displayed minimum can differ from the device-wide thinnest value, and fixed color bounds do not establish scan registration or progression. Colors encode measurement values, not diagnostic categories.

No clinical threshold, NKPI decision rule or optical simulation was introduced. See `SURFACE_DATA.md` for source assumptions and coordinate limits. The package is prepared for the user's upload; it has not been deployed to their GitHub or Streamlit account.
